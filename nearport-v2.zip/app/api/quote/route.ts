import { assertSameOrigin, errorResponse, json, limit, readJson } from "@/lib/server/api";
import { adapterFor } from "@/lib/providers";
import { ProviderError } from "@/lib/providers/types";
import { getRoute } from "@/lib/routing/engine";
import { quoteRequestSchema, semanticQuoteErrors } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    assertSameOrigin(req);
    limit(req, "quote", 20);
    const input = quoteRequestSchema.parse(await readJson(req));
    const route = getRoute(input);
    if (!route.ok) throw new ProviderError(route.reason, 400);
    const bad = semanticQuoteErrors(input, { requireAddresses: false });
    if (bad) throw new ProviderError(bad, 400);
    const quote = await adapterFor(route.provider).getQuote(input);
    return json({ quote });
  } catch (e) {
    return errorResponse(e);
  }
}
