import { errorResponse, json, limit } from "@/lib/server/api";
import { fetchOneClickTokens } from "@/lib/providers/near-intents";
import type { TokenInfo } from "@/lib/tokens";

export const dynamic = "force-dynamic";
let cache: { at: number; tokens: TokenInfo[] } | null = null;

export async function GET(req: Request) {
  try {
    limit(req, "tokens", 30);
    if (!cache || Date.now() - cache.at > 60_000) cache = { at: Date.now(), tokens: await fetchOneClickTokens() };
    return json({ tokens: cache.tokens });
  } catch (e) {
    return errorResponse(e);
  }
}
