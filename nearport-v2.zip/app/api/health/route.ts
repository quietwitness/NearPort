import { ConfigError, getServerConfig, requireDebridgeAffiliate, requireNearFeeRecipient } from "@/lib/server/config";
import { json } from "@/lib/server/api";

export const dynamic = "force-dynamic";

function check(fn: () => unknown): { ready: boolean; reason?: string } {
  try { fn(); return { ready: true }; } catch (e) { return { ready: false, reason: e instanceof ConfigError ? e.message : "Unavailable" }; }
}

/** Public readiness report. Contains only booleans/messages — never values of secrets. */
export async function GET() {
  const cfg = getServerConfig();
  return json({
    nearIntents: check(() => requireNearFeeRecipient(cfg)),
    debridgeEvm: check(() => requireDebridgeAffiliate("evm", cfg)),
    debridgeSolana: check(() => requireDebridgeAffiliate("solana", cfg)),
  });
}
