import { assertSameOrigin, errorResponse, json, limit, readJson } from "@/lib/server/api";
import { ProviderError } from "@/lib/providers/types";

export const dynamic = "force-dynamic";

// Only the read/broadcast methods the app needs. Anything else is refused.
const ALLOWED = new Set([
  "getLatestBlockhash", "getBlockHeight", "getAccountInfo", "getBalance", "getSignatureStatuses",
  "getTokenAccountBalance", "getMinimumBalanceForRentExemption", "sendTransaction", "simulateTransaction",
  "isBlockhashValid", "getFeeForMessage", "getMultipleAccounts", "getRecentPrioritizationFees",
]);

/** Proxies Solana JSON-RPC so a private RPC URL/key (SOLANA_RPC_URL) never reaches the browser. */
export async function POST(req: Request) {
  try {
    assertSameOrigin(req);
    limit(req, "rpc-sol", 240);
    const body = (await readJson(req, 200_000)) as any;
    const calls = Array.isArray(body) ? body : [body];
    if (calls.length === 0 || calls.length > 20) throw new ProviderError("Invalid RPC batch.", 400);
    for (const c of calls) {
      if (!c || c.jsonrpc !== "2.0" || typeof c.method !== "string" || !ALLOWED.has(c.method)) {
        throw new ProviderError("RPC method not allowed.", 400);
      }
    }
    const upstream = (process.env.SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com").trim();
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 20_000);
    try {
      const res = await fetch(upstream, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal, cache: "no-store" });
      const text = await res.text();
      return new Response(text, { status: res.status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
    } finally { clearTimeout(t); }
  } catch (e) {
    if (e instanceof Error && e.name === "AbortError") return json({ error: "RPC timeout" }, 504);
    return errorResponse(e);
  }
}
