import { assertSameOrigin, errorResponse, json, limit, readJson } from "@/lib/server/api";
import { adapterFor } from "@/lib/providers";
import { statusRequestSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    assertSameOrigin(req);
    limit(req, "status", 120);
    const input = statusRequestSchema.parse(await readJson(req));
    const status = await adapterFor(input.provider).getStatus({ trackingId: input.trackingId, txHash: input.txHash });
    return json({ status });
  } catch (e) {
    return errorResponse(e);
  }
}
