import { assertSameOrigin, errorResponse, json, limit, readJson } from "@/lib/server/api";
import { adapterFor } from "@/lib/providers";
import { submitRequestSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    assertSameOrigin(req);
    limit(req, "submit", 20);
    const input = submitRequestSchema.parse(await readJson(req));
    await adapterFor(input.provider).submit({ txHash: input.txHash, trackingId: input.trackingId });
    return json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
