import { BridgeWidget } from "@/components/BridgeWidget";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";

export default function Home() {
  return (
    <main className="site">
      <Header />

      <section className="hero">
        <div className="hero-bg" />
        <div className="hero-copy">
          <div className="eyebrow">FAST <i /> SECURE <i /> NON-CUSTODIAL</div>
          <h1>Move value.<br />Arrive on <em>NEAR.</em></h1>
          <p>NearPort lets you bridge from Solana and EVM chains directly to NEAR. Simple, secure, and built for everyone.</p>
          <div className="benefits">
            <div><b>ϟ</b><span><strong>Fast</strong><small>Settlements</small></span></div>
            <div><b>✓</b><span><strong>Non-custodial</strong><small>You keep control</small></span></div>
            <div><b>◎</b><span><strong>Transparent fee</strong><small>0.10% platform fee</small></span></div>
          </div>
        </div>
        <BridgeWidget />
      </section>

      <section className="chains" id="chains">
        {[
          ["S", "SOLANA", "NEAR", "Bridge from Solana to NEAR"],
          ["Ξ", "ETHEREUM", "NEAR", "Bridge ETH and stablecoins to NEAR"],
          ["B", "BASE", "NEAR", "Bridge from Base to NEAR"],
          ["A", "ARBITRUM", "NEAR", "Bridge from Arbitrum to NEAR"],
        ].map(([icon, a, b, txt]) => (
          <div className="chain-card" key={a}><span className="chain-icon">{icon}</span><b>{a}</b><strong>→ {b}</strong><p>{txt}</p></div>
        ))}
      </section>

      <section className="how" id="how">
        <div className="section-head"><h2>How NearPort works</h2><p>A simple and secure way to get to NEAR in a few steps.</p></div>
        <div className="steps">
          {[
            ["1", "Connect wallet", "Connect your Solana or EVM wallet."],
            ["2", "Choose amount", "Enter the amount and your NEAR account."],
            ["3", "Confirm & send", "Review the fees and sign in your own wallet."],
            ["4", "Receive on NEAR", "Success is shown only after the provider confirms settlement."],
          ].map(([n, t, d]) => (
            <div className="step" key={n}><span>{n}</span><div><h3>{t}</h3><p>{d}</p></div></div>
          ))}
        </div>
        <div className="visual"><img src="/nearport-portal-visual.webp" alt="NearPort portal visual" loading="lazy" /></div>
      </section>

      <section className="faq" id="faq">
        <h2>NearPort, simply.</h2>
        <div className="faq-grid">
          <div><h3>Non-custodial</h3><p>NearPort never asks for your seed phrase or private key and never signs for you. You approve every transaction from your own wallet.</p></div>
          <div><h3>0.10% platform fee</h3><p>A transparent 10 basis-point NearPort fee, applied through the routing provider and shown separately from provider and network fees before you confirm.</p></div>
          <div><h3>Built on proven rails</h3><p>NEAR routes execute through NEAR Intents; other cross-chain routes through deBridge DLN. NearPort is the interface and router — not a new bridge.</p></div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
