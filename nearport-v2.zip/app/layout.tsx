import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Providers } from "@/lib/wallet/providers";

const SITE = process.env.NEXT_PUBLIC_SITE_URL || "https://nearport.app";

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: "NearPort — Your Gateway to NEAR",
  description: "Move value from Solana and EVM chains to NEAR with NearPort.",
  applicationName: "NearPort",
  openGraph: {
    type: "website",
    siteName: "NearPort",
    title: "NearPort — Your Gateway to NEAR",
    description: "Move value from Solana and EVM chains to NEAR with NearPort.",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "NearPort — Move value. Arrive on NEAR." }],
  },
  twitter: {
    card: "summary_large_image",
    title: "NearPort — Your Gateway to NEAR",
    description: "Move value from Solana and EVM chains to NEAR with NearPort.",
    images: ["/og.png"],
  },
};

export const viewport: Viewport = { themeColor: "#020807", colorScheme: "dark" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body><Providers>{children}</Providers></body>
    </html>
  );
}
