import type { Metadata } from "next";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { HistoryList } from "@/components/HistoryList";

export const metadata: Metadata = { title: "Transfers — NearPort", description: "Track your NearPort transfers." };

export default function HistoryPage() {
  return (
    <main className="site">
      <Header />
      <section className="page">
        <h1>Your transfers</h1>
        <p className="muted">Stored only in this browser (public data: amounts, addresses, transaction hashes). Statuses refresh from the provider; a transfer is marked complete only after the provider confirms settlement.</p>
        <HistoryList />
      </section>
      <Footer />
    </main>
  );
}
