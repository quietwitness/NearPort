import http from "node:http";
const sol = "J8eGoHL9vvae95SeGKzSnfihir96fPLPecjGXJkC5YLZ";
http.createServer((req, res) => {
  const u = new URL(req.url, "http://x"); res.setHeader("content-type", "application/json");
  if (u.pathname === "/v0/tokens") return res.end(JSON.stringify([
    { assetId: "nep141:sol.omft.near", blockchain: "sol", symbol: "SOL", decimals: 9 },
    { assetId: "nep141:wrap.near", blockchain: "near", symbol: "wNEAR", decimals: 24 }]));
  if (u.pathname === "/v0/quote") { let b = ""; req.on("data", (c) => (b += c)); req.on("end", () => { const j = JSON.parse(b);
    res.end(JSON.stringify({ quote: { depositAddress: sol, amountIn: j.amount, amountOut: "5000000000000000000000000", timeEstimate: 60, deadline: j.deadline } })); }); return; }
  if (u.pathname === "/v0/status") return res.end(JSON.stringify({ status: u.searchParams.get("depositAddress") ? "PROCESSING" : "FAILED" }));
  if (u.pathname.endsWith("/state")) return res.end(JSON.stringify("Created"));
  if (u.pathname.endsWith("/create-tx")) return res.end(JSON.stringify({ estimation: { srcChainTokenIn: { address: "11111111111111111111111111111111", chainId: 7565164, amount: u.searchParams.get("srcChainTokenInAmount") }, dstChainTokenOut: { address: "0x0000000000000000000000000000000000000000", chainId: 1, amount: "4", recommendedAmount: "4" } }, tx: { data: "ab" }, orderId: "0x" + "cd".repeat(32) }));
  res.statusCode = 404; res.end("{}");
}).listen(4010, () => console.log("mock up"));
