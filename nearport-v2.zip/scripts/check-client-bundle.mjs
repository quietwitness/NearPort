// Fails if any server-side secret NAME or VALUE appears in the browser bundle (.next/static).
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

const SECRET_NAMES = ["ONECLICK_JWT", "DEBRIDGE_ACCESS_TOKEN", "SOLANA_RPC_URL"];
const SECRET_VALUES = SECRET_NAMES.map((n) => process.env[n]).filter((v) => v && v.length >= 8);
const PRIVATE_KEY_HINTS = [/seed phrase/i, /mnemonic/i, /privateKey/];

function walk(d) { return readdirSync(d).flatMap((f) => { const p = join(d, f); return statSync(p).isDirectory() ? walk(p) : [p]; }); }
let bad = 0, scanned = 0;
for (const f of walk(".next/static").filter((f) => /\.(js|css|html)$/.test(f))) {
  const t = readFileSync(f, "utf8"); scanned++;
  for (const n of SECRET_NAMES) if (t.includes(n)) { console.error(`✗ ${n} name found in ${f}`); bad++; }
  for (const v of SECRET_VALUES) if (t.includes(v)) { console.error(`✗ a secret value found in ${f}`); bad++; }
}
console.log(`Scanned ${scanned} client files.`);
if (bad) { console.error(`FAILED: ${bad} problem(s)`); process.exit(1); }
console.log("OK: no server secrets in client bundle.");
