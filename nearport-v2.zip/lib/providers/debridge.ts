import "server-only";
import { bpsOf } from "../amounts";
import { CHAINS } from "../chains";
import { PLATFORM_FEE_BPS, PLATFORM_FEE_PERCENT_DEBRIDGE, getServerConfig, requireDebridgeAffiliate } from "../server/config";
import { fetchJson, providerMessage } from "../server/http";
import { isValidEvmAddress, semanticQuoteErrors, QuoteRequestInput } from "../validation";
import { BuildResult, FeeLine, NormalizedQuote, NormalizedStatus, ProviderAdapter, ProviderError, TransactionPlan } from "./types";

export const DEBRIDGE_NATIVE = {
  evm: "0x0000000000000000000000000000000000000000",
  solana: "11111111111111111111111111111111",
} as const;

/** deBridge says: sign & submit within ~30s of fetching the tx for >99.9% fill probability. */
export const DEBRIDGE_QUOTE_TTL_MS = 30_000;

function tokenParam(chainFamily: "evm" | "solana", address: string | null): string {
  return address ?? DEBRIDGE_NATIVE[chainFamily];
}

function sameAddress(a: string | undefined, b: string): boolean {
  if (!a) return false;
  return a.toLowerCase() === b.toLowerCase();
}

/** Builds the create-tx query. Only NearPort-controlled parameters are ever sent — no caller-supplied keys. */
export function buildCreateTxParams(req: QuoteRequestInput, { build }: { build: boolean }): URLSearchParams {
  const src = CHAINS[req.sourceChain];
  const dst = CHAINS[req.destinationChain];
  if (!src.debridgeChainId || !dst.debridgeChainId || src.family === "near" || dst.family === "near") {
    throw new ProviderError("deBridge does not support this chain pair.", 400);
  }
  // Affiliate fee beneficiary MUST be on the origin chain (deBridge docs: Solana public key / EVM address).
  const affiliate = requireDebridgeAffiliate(src.family === "solana" ? "solana" : "evm");
  const cfg = getServerConfig().debridge;

  const p = new URLSearchParams({
    srcChainId: String(src.debridgeChainId),
    srcChainTokenIn: tokenParam(src.family, req.sourceToken.address),
    srcChainTokenInAmount: req.amount,
    dstChainId: String(dst.debridgeChainId),
    dstChainTokenOut: tokenParam(dst.family, req.destinationToken.address),
    dstChainTokenOutAmount: "auto",
    prependOperatingExpenses: "true",
    // 0.1 means 0.1% in deBridge's API (NOT basis points).
    affiliateFeePercent: PLATFORM_FEE_PERCENT_DEBRIDGE,
    affiliateFeeRecipient: affiliate.recipient,
    referralCode: affiliate.referralCode,
  });
  if (cfg.accessToken) p.set("accesstoken", cfg.accessToken);
  if (build) {
    p.set("dstChainTokenOutRecipient", req.recipient!);
    p.set("srcChainOrderAuthorityAddress", req.sender!);
    // Must be user-controlled: the recipient the user typed.
    p.set("dstChainOrderAuthorityAddress", req.recipient!);
    p.set("senderAddress", req.sender!);
  }
  return p;
}

function friendlyError(data: any, fallback: string): string {
  const id = data?.errorId;
  if (id === "ERROR_LOW_GIVE_AMOUNT") return "Amount is too small to cover the bridge's operating costs. Try a larger amount.";
  return providerMessage(data, fallback);
}

async function createTx(req: QuoteRequestInput, build: boolean) {
  const params = buildCreateTxParams(req, { build });
  const res = await fetchJson(`${getServerConfig().debridge.baseUrl}/dln/order/create-tx?${params}`, { headers: { Accept: "application/json" } });
  if (!res.ok) throw new ProviderError(friendlyError(res.data, "deBridge could not quote this route."), res.status >= 500 ? 502 : 400, res.data);
  return res.data;
}

function normalize(req: QuoteRequestInput, data: any): NormalizedQuote {
  const est = data?.estimation;
  const inTok = est?.srcChainTokenIn;
  const outTok = est?.dstChainTokenOut;
  if (!inTok?.amount || !outTok) throw new ProviderError("deBridge returned an unexpected quote response.", 502);

  const src = CHAINS[req.sourceChain];
  const dst = CHAINS[req.destinationChain];
  // Sanity checks: the provider answered for the route that was requested.
  if (Number(inTok.chainId) !== src.debridgeChainId || Number(outTok.chainId) !== dst.debridgeChainId) {
    throw new ProviderError("deBridge returned a quote for a different route. Nothing was sent.", 502);
  }
  const wantIn = tokenParam(src.family as "evm" | "solana", req.sourceToken.address);
  const wantOut = tokenParam(dst.family as "evm" | "solana", req.destinationToken.address);
  if (!sameAddress(inTok.address, wantIn) || !sameAddress(outTok.address, wantOut)) {
    throw new ProviderError("deBridge returned a quote for a different token. Nothing was sent.", 502);
  }

  const amountIn = String(inTok.amount);
  const amountOut = String(outTok.recommendedAmount ?? outTok.amount);
  const fees: FeeLine[] = [
    { label: "NearPort fee", platform: true, amount: bpsOf(BigInt(req.amount), PLATFORM_FEE_BPS).toString(), symbol: req.sourceToken.symbol, decimals: req.sourceToken.decimals },
  ];
  if (inTok.approximateOperatingExpense) {
    fees.push({ label: "Solver operating expense", amount: String(inTok.approximateOperatingExpense), symbol: req.sourceToken.symbol, decimals: req.sourceToken.decimals });
  }
  if (data.fixFee) {
    fees.push({ label: "deBridge fixed fee", amount: String(BigInt(data.fixFee)), symbol: src.nativeSymbol, decimals: src.nativeDecimals });
  }
  if (typeof data.protocolFeeApproximateUsdValue === "number") {
    fees.push({ label: "deBridge protocol fee", text: `≈ $${data.protocolFeeApproximateUsdValue.toFixed(2)}` });
  }
  const netFee = data.estimatedTransactionFee?.total;
  fees.push(netFee
    ? { label: `${src.name} network fee (est.)`, amount: String(netFee), symbol: src.nativeSymbol, decimals: src.nativeDecimals, estimated: true }
    : { label: `${src.name} network fee`, text: "Paid from your wallet when you sign" });

  const warnings = ["deBridge orders are fixed-price: no slippage, but an unfilled order can be cancelled and refunded."];
  if (typeof data.usdPriceImpact === "number" && Math.abs(data.usdPriceImpact) >= 1) {
    warnings.push(`High price impact (${data.usdPriceImpact.toFixed(2)}%).`);
  }
  return {
    provider: "debridge",
    providerLabel: "deBridge",
    sourceChain: req.sourceChain,
    destinationChain: req.destinationChain,
    amountIn,
    amountOut,
    minAmountOut: amountOut,
    estimatedSeconds: typeof data.order?.approximateFulfillmentDelay === "number" ? data.order.approximateFulfillmentDelay : undefined,
    fees,
    platformFeeBps: PLATFORM_FEE_BPS,
    expiresAt: new Date(Date.now() + DEBRIDGE_QUOTE_TTL_MS).toISOString(),
    trackingId: data.orderId || undefined,
    warnings,
  };
}

const HEX = /^(0x)?[0-9a-fA-F]+$/;

export function planFromTx(req: QuoteRequestInput, quote: NormalizedQuote, tx: any): TransactionPlan {
  const src = CHAINS[req.sourceChain];
  if (!tx?.data || typeof tx.data !== "string" || !HEX.test(tx.data)) throw new ProviderError("deBridge did not return transaction data.", 502);
  if (src.family === "solana") return { kind: "solana-versioned", dataHex: tx.data.replace(/^0x/, "") };
  if (!tx.to || !isValidEvmAddress(tx.to)) throw new ProviderError("deBridge returned an invalid transaction target.", 502);
  const value = tx.value == null ? "0" : String(tx.value);
  const valueDec = value.startsWith("0x") ? BigInt(value).toString() : BigInt(value).toString();
  const plan: TransactionPlan = { kind: "evm", chainId: src.evmChainId!, to: tx.to, data: tx.data, value: valueDec };
  if (req.sourceToken.address) {
    // ERC-20: `tx.to` is the spender for approve() (deBridge docs).
    plan.approval = { token: req.sourceToken.address, spender: tx.to, amount: quote.amountIn };
  }
  return plan;
}

export function mapDebridgeState(state: string): NormalizedStatus {
  switch (state) {
    case "Fulfilled":
    case "SentUnlock":
    case "ClaimedUnlock":
      return { code: "complete", raw: state };
    case "OrderCancelled":
    case "SentOrderCancel":
    case "ClaimedOrderCancel":
      return { code: "refunded", raw: state, message: "The order was cancelled. Your funds return to your source-chain address." };
    case "Created":
      return { code: "processing", raw: state };
    case "None":
      return { code: "source-confirming", raw: state };
    default:
      return { code: "unknown", raw: state };
  }
}

export const debridgeAdapter: ProviderAdapter = {
  id: "debridge",

  async getQuote(req) {
    const err = semanticQuoteErrors(req, { requireAddresses: false });
    if (err) throw new ProviderError(err, 400);
    const data = await createTx(req, false);
    return normalize(req, data);
  },

  async buildTransaction(req): Promise<BuildResult> {
    const err = semanticQuoteErrors(req, { requireAddresses: true });
    if (err) throw new ProviderError(err, 400);
    const data = await createTx(req, true);
    const quote = normalize(req, data);
    if (!quote.trackingId) throw new ProviderError("deBridge did not return an order id.", 502);
    return { quote, plan: planFromTx(req, quote, data.tx) };
  },

  async submit() {
    /* deBridge orders are created by the user's on-chain transaction; nothing to notify. */
  },

  async getStatus({ trackingId }) {
    const url = `${getServerConfig().debridge.statsUrl}/api/Orders/${encodeURIComponent(trackingId)}/state`;
    const res = await fetchJson(url, { headers: { Accept: "application/json" } });
    if (res.status === 404) return { code: "source-confirming", raw: "NOT_INDEXED" };
    if (!res.ok) throw new ProviderError(providerMessage(res.data, "Could not read order status."), 502, res.data);
    const d = res.data;
    const state = typeof d === "string" ? d : d?.raw ?? d?.state ?? d?.status ?? "None";
    return mapDebridgeState(String(state).replace(/^"|"$/g, ""));
  },
};
