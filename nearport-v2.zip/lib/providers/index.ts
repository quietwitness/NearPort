import "server-only";
import { debridgeAdapter } from "./debridge";
import { nearIntentsAdapter } from "./near-intents";
import { ProviderAdapter, ProviderId } from "./types";

const adapters: Record<ProviderId, ProviderAdapter> = {
  "near-intents": nearIntentsAdapter,
  debridge: debridgeAdapter,
};

export function adapterFor(id: ProviderId): ProviderAdapter {
  return adapters[id];
}
