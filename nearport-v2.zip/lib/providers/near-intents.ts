import "server-only";
import { encodeFunctionData, erc20Abi } from "viem";
import { bpsOf } from "../amounts";
import { CHAINS, ChainKey } from "../chains";
import { ConfigError, PLATFORM_FEE_BPS, getServerConfig, requireNearFeeRecipient } from "../server/config";
import { fetchJson, providerMessage } from "../server/http";
import { ONECLICK_SYMBOL_ALLOWLIST, TokenInfo } from "../tokens";
import { isValidEvmAddress, isValidSolanaAddress, semanticQuoteErrors, QuoteRequestInput } from "../validation";
import { BuildResult, FeeLine, NormalizedQuote, NormalizedStatus, ProviderAdapter, ProviderError, TransactionPlan } from "./types";

// ---------------------------------------------------------------------------
// Fee handling — verified against docs.near-intents.org "Fee Configuration":
//  * `appFees: [{ recipient, fee }]`, `fee` = integer basis points charged from the INPUT token.
//  * Authenticated (JWT) requests: the requested fee is split 50/50 with 1Click; 1Click's half has a
//    20 bps floor. So requesting 10 bps would pay NearPort only 5 bps and charge the user 25 bps in total.
//  * To make NearPort receive exactly PLATFORM_FEE_BPS we request 2x. The provider's own share is then
//    shown as a separate line in the UI. Override with ONECLICK_APP_FEE_REQUEST_BPS if your partner
//    agreement differs.
// ---------------------------------------------------------------------------

export interface FeeSplit { requestBps: number; platformBps: number; providerBps: number }

export function hasJwt(): boolean { return !!getServerConfig().oneClick.jwt; }

/**
 * With a JWT: requested fee is split 50/50 with 1Click (their half has a 20 bps floor).
 * Without a JWT: NearPort keeps the full requested fee and 1Click adds 25 bps on top.
 */
export function oneClickFeeSplit(requestBps: number, authenticated = true): FeeSplit {
  if (!authenticated) return { requestBps, platformBps: requestBps, providerBps: 25 };
  const platformBps = Math.ceil(requestBps / 2);
  const providerBps = Math.max(Math.floor(requestBps / 2), 20);
  return { requestBps, platformBps, providerBps };
}

export function oneClickAppFeeRequestBps(targetBps = PLATFORM_FEE_BPS): number {
  const override = (process.env.ONECLICK_APP_FEE_REQUEST_BPS ?? "").trim();
  if (override) {
    const n = Number(override);
    if (!Number.isInteger(n) || n < 0 || n > 400) throw new ConfigError("ONECLICK_APP_FEE_REQUEST_BPS must be an integer between 0 and 400.");
    return n;
  }
  // Authenticated: request 2x so NearPort keeps the target. Unauthenticated: no split, request the target itself.
  return hasJwt() ? targetBps * 2 : targetBps;
}

// ---------------------------------------------------------------------------

/** JWT is optional per the 1Click docs (unauthenticated requests work but 1Click adds its own 25 bps). Server-side only. */
function authHeaders(json = true): Record<string, string> {
  const { jwt } = getServerConfig().oneClick;
  const h: Record<string, string> = {};
  if (jwt) h.Authorization = `Bearer ${jwt}`;
  if (json) h["Content-Type"] = "application/json";
  return h;
}

export function chainKeyForBlockchain(blockchain: string): ChainKey | undefined {
  const b = blockchain.toLowerCase();
  return (Object.values(CHAINS).find((c) => c.oneClickBlockchains.includes(b))?.key) as ChainKey | undefined;
}

export function normalizeOneClickTokens(raw: unknown): TokenInfo[] {
  const list: any[] = Array.isArray(raw) ? raw : Array.isArray((raw as any)?.tokens) ? (raw as any).tokens : [];
  const out: TokenInfo[] = [];
  const seen = new Set<string>();
  for (const t of list) {
    const assetId: string | undefined = t?.assetId ?? t?.defuse_asset_id;
    const chain = typeof t?.blockchain === "string" ? chainKeyForBlockchain(t.blockchain) : undefined;
    if (!assetId || !chain) continue;
    let symbol = String(t.symbol ?? "").toUpperCase();
    const decimals = Number(t.decimals);
    if (!Number.isInteger(decimals)) continue;
    let address: string | null = t.contractAddress || t.address || null;
    if (chain === "near" && assetId === "nep141:wrap.near") { symbol = "NEAR"; address = null; }
    if (!ONECLICK_SYMBOL_ALLOWLIST.has(symbol)) continue;
    const native = CHAINS[chain].nativeSymbol;
    if (symbol === native) { if (address) continue; } // wrapped variants of the native symbol carry a contract address
    else if (symbol === "ETH" || symbol === "SOL" || symbol === "NEAR" || symbol === "WNEAR") continue; // not this chain's native asset
    else if (chain !== "near" && !address) continue; // USDC/USDT must have a contract/mint address for us to send
    const key = `${chain}:${symbol}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ chain, symbol, name: symbol, decimals, address, assetId });
  }
  return out;
}

export async function fetchOneClickTokens(): Promise<TokenInfo[]> {
  const res = await fetchJson(`${getServerConfig().oneClick.baseUrl}/v0/tokens`, { headers: { Accept: "application/json" } });
  if (!res.ok) throw new ProviderError(providerMessage(res.data, "Could not load NEAR Intents assets."), 502);
  return normalizeOneClickTokens(res.data);
}

export function buildQuoteBody(req: QuoteRequestInput, dry: boolean, now = Date.now()) {
  const feeRecipient = requireNearFeeRecipient();
  const requestBps = oneClickAppFeeRequestBps();
  if (!req.sourceToken.assetId || !req.destinationToken.assetId) {
    throw new ProviderError("Missing NEAR Intents asset id for this token. Reload the page and try again.", 400);
  }
  const body: Record<string, unknown> = {
    dry,
    swapType: "EXACT_INPUT",
    slippageTolerance: req.slippageBps,
    originAsset: req.sourceToken.assetId,
    depositType: "ORIGIN_CHAIN",
    destinationAsset: req.destinationToken.assetId,
    amount: req.amount,
    refundTo: req.sender,
    refundType: "ORIGIN_CHAIN",
    recipient: req.recipient,
    recipientType: "DESTINATION_CHAIN",
    deadline: new Date(now + 30 * 60_000).toISOString(),
    appFees: requestBps > 0 ? [{ recipient: feeRecipient, fee: requestBps }] : [],
  };
  return { body, requestBps };
}

function requireNearRoute(req: QuoteRequestInput) {
  if (req.destinationChain !== "near") throw new ProviderError("NEAR Intents adapter only handles NEAR destinations.", 400);
  if (req.sourceChain === "near") throw new ProviderError("NEAR as a source chain is not supported.", 400);
  if (!req.sender || !req.recipient) throw new ProviderError("Connect a wallet and enter a NEAR recipient to get a quote.", 400);
  const err = semanticQuoteErrors(req, { requireAddresses: true });
  if (err) throw new ProviderError(err, 400);
}

function normalizeQuote(req: QuoteRequestInput, data: any, requestBps: number): NormalizedQuote {
  const q = data?.quote ?? data;
  if (!q || q.amountOut == null) throw new ProviderError("NEAR Intents returned an unexpected quote response.", 502);
  const split = oneClickFeeSplit(requestBps, hasJwt());
  const src = CHAINS[req.sourceChain];
  const amountIn = String(q.amountIn ?? req.amount);
  const fees: FeeLine[] = [
    { label: "NearPort fee", platform: true, amount: bpsOf(BigInt(amountIn), split.platformBps).toString(), symbol: req.sourceToken.symbol, decimals: req.sourceToken.decimals },
    { label: "NEAR Intents fee", estimated: true, amount: bpsOf(BigInt(amountIn), split.providerBps).toString(), symbol: req.sourceToken.symbol, decimals: req.sourceToken.decimals },
    { label: `${src.name} network fee`, text: "Paid from your wallet when you sign" },
  ];
  const expiresAt = q.timeWhenInactive || q.deadline || new Date(Date.now() + 5 * 60_000).toISOString();
  const warnings: string[] = [];
  return {
    provider: "near-intents",
    providerLabel: "NEAR Intents",
    sourceChain: req.sourceChain,
    destinationChain: req.destinationChain,
    amountIn,
    amountOut: String(q.amountOut),
    minAmountOut: q.minAmountOut != null ? String(q.minAmountOut) : undefined,
    slippageBps: req.slippageBps,
    estimatedSeconds: typeof q.timeEstimate === "number" ? q.timeEstimate : undefined,
    fees,
    platformFeeBps: split.platformBps,
    expiresAt: new Date(expiresAt).toISOString(),
    trackingId: q.depositAddress || undefined,
    warnings,
  };
}

export function depositPlan(req: QuoteRequestInput, depositAddress: string, amount: string): TransactionPlan {
  const src = CHAINS[req.sourceChain];
  if (src.family === "evm") {
    if (!isValidEvmAddress(depositAddress)) throw new ProviderError("Provider returned an invalid EVM deposit address.", 502);
    const token = req.sourceToken.address;
    if (!token) return { kind: "evm", chainId: src.evmChainId!, to: depositAddress, data: "0x", value: amount };
    if (!isValidEvmAddress(token)) throw new ProviderError("Invalid token address.", 400);
    const data = encodeFunctionData({ abi: erc20Abi, functionName: "transfer", args: [depositAddress as `0x${string}`, BigInt(amount)] });
    return { kind: "evm", chainId: src.evmChainId!, to: token, data, value: "0" };
  }
  if (src.family === "solana") {
    if (!isValidSolanaAddress(depositAddress)) throw new ProviderError("Provider returned an invalid Solana deposit address.", 502);
    return { kind: "solana-transfer", to: depositAddress, mint: req.sourceToken.address, amount, decimals: req.sourceToken.decimals };
  }
  throw new ProviderError("Unsupported source chain.", 400);
}

export function mapOneClickStatus(data: any): NormalizedStatus {
  const raw = String(data?.status ?? "UNKNOWN");
  const destHash = data?.swapDetails?.destinationChainTxHashes?.[0]?.hash;
  switch (raw) {
    case "SUCCESS": return { code: "complete", raw, destinationTxHash: destHash };
    case "PROCESSING": return { code: "processing", raw };
    case "KNOWN_DEPOSIT_TX": return { code: "source-confirming", raw };
    case "PENDING_DEPOSIT": return { code: "awaiting-deposit", raw };
    case "REFUNDED": return { code: "refunded", raw, message: "The swap was not completed and your funds were refunded to your wallet." };
    case "INCOMPLETE_DEPOSIT": return { code: "failed", raw, message: "The deposit was below the required amount. Funds are refunded after the quote deadline." };
    case "FAILED": return { code: "failed", raw, message: "The provider reported that the swap failed." };
    default: return { code: "unknown", raw };
  }
}

export const nearIntentsAdapter: ProviderAdapter = {
  id: "near-intents",

  async getQuote(req) {
    requireNearRoute(req);
    const { body, requestBps } = buildQuoteBody(req, true);
    const res = await fetchJson(`${getServerConfig().oneClick.baseUrl}/v0/quote`, { method: "POST", headers: authHeaders(), body: JSON.stringify(body) });
    if (!res.ok) throw new ProviderError(providerMessage(res.data, "NEAR Intents could not quote this route."), res.status === 400 ? 400 : 502, res.data);
    return normalizeQuote(req, res.data, requestBps);
  },

  async buildTransaction(req): Promise<BuildResult> {
    requireNearRoute(req);
    const { body, requestBps } = buildQuoteBody(req, false);
    const res = await fetchJson(`${getServerConfig().oneClick.baseUrl}/v0/quote`, { method: "POST", headers: authHeaders(), body: JSON.stringify(body) });
    if (!res.ok) throw new ProviderError(providerMessage(res.data, "NEAR Intents could not prepare this swap."), res.status === 400 ? 400 : 502, res.data);
    const quote = normalizeQuote(req, res.data, requestBps);
    if (!quote.trackingId) throw new ProviderError("NEAR Intents did not return a deposit address.", 502);
    // The wallet must send exactly what the user reviewed.
    if (BigInt(quote.amountIn) !== BigInt(req.amount)) throw new ProviderError("Provider returned a different input amount than requested. Nothing was sent.", 502);
    return { quote, plan: depositPlan(req, quote.trackingId, req.amount) };
  },

  async submit({ txHash, trackingId }) {
    const res = await fetchJson(`${getServerConfig().oneClick.baseUrl}/v0/deposit/submit`, {
      method: "POST", headers: authHeaders(), body: JSON.stringify({ txHash, depositAddress: trackingId }),
    });
    if (!res.ok) throw new ProviderError(providerMessage(res.data, "NEAR Intents did not accept the deposit notification."), 502, res.data);
  },

  async getStatus({ trackingId }) {
    const qs = new URLSearchParams({ depositAddress: trackingId });
    const res = await fetchJson(`${getServerConfig().oneClick.baseUrl}/v0/status?${qs}`, { headers: authHeaders(false) });
    if (res.status === 404) return { code: "awaiting-deposit", raw: "NOT_FOUND" };
    if (!res.ok) throw new ProviderError(providerMessage(res.data, "Could not read swap status."), 502, res.data);
    return mapOneClickStatus(res.data);
  },
};
