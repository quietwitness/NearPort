import type { ChainKey } from "../chains";
import type { QuoteRequestInput } from "../validation";

export type ProviderId = "near-intents" | "debridge";

export interface FeeLine {
  label: string;
  /** Base units, when known. */
  amount?: string;
  symbol?: string;
  decimals?: number;
  /** Human-readable text when no exact amount is available (e.g. "Dynamic"). */
  text?: string;
  /** true when the value is NearPort's platform fee. */
  platform?: boolean;
  /** true when this is an estimate derived from documented provider terms rather than the quote response */
  estimated?: boolean;
}

export interface NormalizedQuote {
  provider: ProviderId;
  providerLabel: string;
  sourceChain: ChainKey;
  destinationChain: ChainKey;
  /** Amount the user is sending, base units (what the wallet will spend, excluding gas). */
  amountIn: string;
  /** Estimated amount received on destination, base units. */
  amountOut: string;
  /** Minimum guaranteed amount received, base units (when the provider reports one). */
  minAmountOut?: string;
  slippageBps?: number;
  estimatedSeconds?: number;
  fees: FeeLine[];
  platformFeeBps: number;
  /** ISO time after which the transaction data / quote must be re-requested. */
  expiresAt: string;
  /** Provider order id (deBridge) or deposit address (NEAR Intents). Present only after build. */
  trackingId?: string;
  warnings: string[];
}

/** What the user's wallet has to do. Everything here is signed by the user's own wallet. */
export type TransactionPlan =
  | { kind: "evm"; chainId: number; to: string; data: string; value: string; approval?: { token: string; spender: string; amount: string } }
  | { kind: "solana-versioned"; dataHex: string }
  | { kind: "solana-transfer"; to: string; mint: string | null; amount: string; decimals: number };

export interface BuildResult {
  quote: NormalizedQuote;
  plan: TransactionPlan;
}

export type NormalizedStatusCode =
  | "awaiting-deposit"
  | "source-confirming"
  | "processing"
  | "complete"
  | "refunded"
  | "failed"
  | "unknown";

export interface NormalizedStatus {
  code: NormalizedStatusCode;
  /** raw provider state, for display/debugging */
  raw: string;
  destinationTxHash?: string;
  message?: string;
}

export interface ProviderAdapter {
  id: ProviderId;
  /** Preview quote — no signable transaction. */
  getQuote(req: QuoteRequestInput): Promise<NormalizedQuote>;
  /** Fresh quote + transaction data for the user's wallet to sign. Requires sender + recipient. */
  buildTransaction(req: QuoteRequestInput): Promise<BuildResult>;
  /** Notify the provider that the user broadcast the source transaction (no-op where not needed). */
  submit(args: { txHash: string; trackingId: string }): Promise<void>;
  getStatus(args: { trackingId: string; txHash?: string }): Promise<NormalizedStatus>;
}

export class ProviderError extends Error {
  constructor(message: string, public readonly status = 502, public readonly details?: unknown) {
    super(message);
  }
}
