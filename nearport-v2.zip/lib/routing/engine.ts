import { CHAINS, ChainKey, isChainKey } from "../chains";
import type { ProviderId } from "../providers/types";

export interface RouteRequest {
  sourceChain: ChainKey;
  destinationChain: ChainKey;
  sourceToken?: unknown;
  destinationToken?: unknown;
  amount?: unknown;
}

export type RouteDecision = { ok: true; provider: ProviderId } | { ok: false; reason: string };

/**
 * Provider selection. Extend here to add providers:
 *   - destination NEAR  -> NEAR Intents (1Click)
 *   - everything else supported -> deBridge DLN
 */
export function getRoute(req: RouteRequest): RouteDecision {
  const { sourceChain, destinationChain } = req;
  if (!isChainKey(sourceChain) || !isChainKey(destinationChain)) return { ok: false, reason: "Unsupported chain." };
  if (sourceChain === destinationChain) return { ok: false, reason: "Source and destination chains must differ." };
  if (sourceChain === "near") return { ok: false, reason: "Sending from NEAR is not supported yet." };
  if (destinationChain === "near") return { ok: true, provider: "near-intents" };
  const s = CHAINS[sourceChain], d = CHAINS[destinationChain];
  if (s.debridgeChainId && d.debridgeChainId) return { ok: true, provider: "debridge" };
  return { ok: false, reason: `No provider supports ${s.name} → ${d.name}.` };
}
