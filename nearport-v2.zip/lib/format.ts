import { formatUnits } from "./amounts";
import type { FeeLine } from "./providers/types";

export function shortAddress(a: string, head = 4, tail = 4): string {
  if (!a) return "";
  return a.length <= head + tail + 3 ? a : `${a.slice(0, a.startsWith("0x") ? head + 2 : head)}…${a.slice(-tail)}`;
}

export function fmtToken(amount: string | bigint, decimals: number, symbol?: string, maxFraction = 6): string {
  const s = formatUnits(amount, decimals, maxFraction);
  return symbol ? `${s} ${symbol}` : s;
}

export function fmtFee(f: FeeLine): string {
  if (f.amount != null && f.symbol && f.decimals != null) return `${f.estimated ? "≈ " : ""}${fmtToken(f.amount, f.decimals, f.symbol, 6)}`;
  return f.text ?? "Dynamic";
}

export function fmtDuration(sec?: number): string {
  if (!sec || sec <= 0) return "—";
  if (sec < 90) return `~${Math.round(sec)}s`;
  return `~${Math.round(sec / 60)} min`;
}

export function isMobileUA(): boolean {
  return typeof navigator !== "undefined" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
}
