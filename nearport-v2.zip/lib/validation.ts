import { PublicKey } from "@solana/web3.js";
import { isAddress } from "viem";
import { z } from "zod";
import { CHAINS, ChainFamily, ChainKey, isChainKey } from "./chains";

// ---------- address validation ----------

export function isValidSolanaAddress(v: string): boolean {
  if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(v)) return false;
  try {
    return new PublicKey(v).toBytes().length === 32;
  } catch {
    return false;
  }
}

export function isValidEvmAddress(v: string): boolean {
  return /^0x[0-9a-fA-F]{40}$/.test(v) && isAddress(v, { strict: false });
}

const NEAR_NAMED = /^(([a-z\d]+[-_])*[a-z\d]+\.)*([a-z\d]+[-_])*[a-z\d]+$/;
export function isValidNearAccount(v: string): boolean {
  if (v.length < 2 || v.length > 64) return false;
  if (/^[0-9a-f]{64}$/.test(v)) return true; // implicit account
  if (/^0x[0-9a-f]{40}$/.test(v)) return true; // eth-implicit account
  return NEAR_NAMED.test(v);
}

export function isValidAddressFor(family: ChainFamily, v: string): boolean {
  if (family === "solana") return isValidSolanaAddress(v);
  if (family === "evm") return isValidEvmAddress(v);
  return isValidNearAccount(v);
}

export function isValidTxHash(v: string): boolean {
  return /^0x[0-9a-fA-F]{64}$/.test(v) || /^[1-9A-HJ-NP-Za-km-z]{60,100}$/.test(v);
}

// ---------- request schemas (strict: unknown keys are rejected) ----------

const chainKey = z.string().refine(isChainKey, "Unsupported chain") as unknown as z.ZodType<ChainKey>;
const uintString = z.string().regex(/^\d{1,40}$/, "Amount must be an integer in base units");
const tokenRef = z.object({
  symbol: z.string().min(1).max(20),
  decimals: z.number().int().min(0).max(36),
  /** Contract / mint address, or null for the chain's native asset. */
  address: z.string().max(100).nullable(),
  /** NEAR Intents asset id (from /api/tokens). Only used by the NEAR Intents adapter. */
  assetId: z.string().max(200).optional(),
}).strict();

export const quoteRequestSchema = z.object({
  sourceChain: chainKey,
  destinationChain: chainKey,
  sourceToken: tokenRef,
  destinationToken: tokenRef,
  /** integer string in the source token's base units */
  amount: uintString,
  /** slippage in basis points, 1..500 (0.01% .. 5%) */
  slippageBps: z.number().int().min(1).max(500).default(100),
  sender: z.string().min(1).max(100).optional(),
  recipient: z.string().min(1).max(100).optional(),
}).strict();
export type QuoteRequestInput = z.infer<typeof quoteRequestSchema>;

export const statusRequestSchema = z.object({
  provider: z.enum(["near-intents", "debridge"]),
  /** 1Click: deposit address. deBridge: order id. */
  trackingId: z.string().min(8).max(200),
  txHash: z.string().max(200).optional(),
}).strict();

export const submitRequestSchema = z.object({
  provider: z.enum(["near-intents", "debridge"]),
  txHash: z.string().refine(isValidTxHash, "Invalid transaction hash"),
  trackingId: z.string().min(8).max(200),
}).strict();

/** Validates addresses/tokens/amount beyond the shape. Returns a human-readable error or null. */
export function semanticQuoteErrors(q: QuoteRequestInput, { requireAddresses }: { requireAddresses: boolean }): string | null {
  const src = CHAINS[q.sourceChain];
  const dst = CHAINS[q.destinationChain];
  if (q.sourceChain === q.destinationChain) return "Source and destination chains must differ.";
  if (BigInt(q.amount) <= 0n) return "Amount must be greater than zero.";
  if (requireAddresses) {
    if (!q.sender || !isValidAddressFor(src.family, q.sender)) return `Invalid ${src.name} sender address.`;
    if (!q.recipient || !isValidAddressFor(dst.family, q.recipient)) return `Invalid ${dst.name} recipient address.`;
  } else {
    if (q.sender && !isValidAddressFor(src.family, q.sender)) return `Invalid ${src.name} sender address.`;
    if (q.recipient && !isValidAddressFor(dst.family, q.recipient)) return `Invalid ${dst.name} recipient address.`;
  }
  for (const [label, chain, token] of [["source", src, q.sourceToken], ["destination", dst, q.destinationToken]] as const) {
    if (token.address !== null && !isValidAddressFor(chain.family === "near" ? "near" : chain.family, token.address) && chain.family !== "near") {
      return `Invalid ${label} token address.`;
    }
  }
  return null;
}
