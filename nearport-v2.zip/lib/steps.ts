/** The 11-step user journey shown in the UI. */
export const STEPS = [
  "Connect wallet",
  "Enter amount",
  "Enter destination",
  "Get quote",
  "Review quote",
  "Confirm in wallet",
  "Transaction submitted",
  "Waiting for source confirmation",
  "Provider processing",
  "Destination transaction",
  "Complete",
] as const;

export type ExecStage =
  | "idle" | "building" | "approving" | "wallet" | "submitted" | "source-confirming" | "processing" | "destination" | "complete" | "failed" | "refunded";

/** 1-based active step. */
export function activeStep(p: { connected: boolean; hasAmount: boolean; hasRecipient: boolean; hasQuote: boolean; stage: ExecStage }): number {
  switch (p.stage) {
    case "building": case "approving": case "wallet": return 6;
    case "submitted": return 7;
    case "source-confirming": return 8;
    case "processing": return 9;
    case "destination": return 10;
    case "complete": return 11;
    case "failed": case "refunded": return 9;
  }
  if (!p.connected) return 1;
  if (!p.hasAmount) return 2;
  if (!p.hasRecipient) return 3;
  return p.hasQuote ? 5 : 4;
}
