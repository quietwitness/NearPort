"use client";
import { createConfig, http } from "wagmi";
import { arbitrum, base, mainnet } from "wagmi/chains";
import { injected, walletConnect } from "wagmi/connectors";

/**
 * EVM wallet layer. To add another EVM network:
 *   1. add its viem chain to `chains` + `transports` here,
 *   2. add it to CHAINS / SOURCE_CHAINS in lib/chains.ts (+ token entries in lib/tokens.ts).
 * EIP-6963 discovery is on by default, so MetaMask, Rabby, Coinbase Wallet, Brave… each appear as their own connector.
 */
export const WALLETCONNECT_PROJECT_ID = process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID ?? "";

export const wagmiConfig = createConfig({
  chains: [mainnet, base, arbitrum],
  connectors: [
    injected(),
    ...(WALLETCONNECT_PROJECT_ID
      ? [walletConnect({ projectId: WALLETCONNECT_PROJECT_ID, showQrModal: true, metadata: { name: "NearPort", description: "Your gateway to NEAR.", url: "https://nearport.app", icons: [] } })]
      : []),
  ],
  transports: {
    [mainnet.id]: http(process.env.NEXT_PUBLIC_RPC_ETHEREUM || undefined),
    [base.id]: http(process.env.NEXT_PUBLIC_RPC_BASE || undefined),
    [arbitrum.id]: http(process.env.NEXT_PUBLIC_RPC_ARBITRUM || undefined),
  },
  ssr: true,
});
