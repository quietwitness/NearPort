"use client";
import { ConnectionProvider, WalletProvider } from "@solana/wallet-adapter-react";
import { PhantomWalletAdapter } from "@solana/wallet-adapter-phantom";
import { SolflareWalletAdapter } from "@solana/wallet-adapter-solflare";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactNode, useEffect, useMemo, useState } from "react";
import { WagmiProvider } from "wagmi";
import { wagmiConfig } from "./wagmi-config";

export function Providers({ children }: { children: ReactNode }) {
  const [queryClient] = useState(() => new QueryClient());
  // Solana RPC goes through our allow-listed proxy so a private RPC key stays server-side.
  const [endpoint, setEndpoint] = useState("https://api.mainnet-beta.solana.com");
  useEffect(() => setEndpoint(`${window.location.origin}/api/rpc/solana`), []);
  const wallets = useMemo(() => [new PhantomWalletAdapter(), new SolflareWalletAdapter()], []);

  return (
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={queryClient}>
        <ConnectionProvider endpoint={endpoint} config={{ commitment: "confirmed" }}>
          <WalletProvider wallets={wallets} autoConnect>{children}</WalletProvider>
        </ConnectionProvider>
      </QueryClientProvider>
    </WagmiProvider>
  );
}
