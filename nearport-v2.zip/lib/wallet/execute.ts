"use client";
import {
  createAssociatedTokenAccountIdempotentInstruction,
  createTransferCheckedInstruction,
  getAssociatedTokenAddressSync,
} from "@solana/spl-token";
import type { WalletContextState } from "@solana/wallet-adapter-react";
import { Connection, PublicKey, SystemProgram, Transaction, VersionedTransaction } from "@solana/web3.js";
import { getAccount, readContract, sendTransaction, switchChain, waitForTransactionReceipt, writeContract } from "@wagmi/core";
import { erc20Abi } from "viem";
import type { TransactionPlan } from "../providers/types";
import { wagmiConfig } from "./wagmi-config";

/** Everything here is signed by the USER's wallet. NearPort never sees keys and signs nothing itself. */

export function humanizeWalletError(e: any): string {
  const msg = String(e?.shortMessage ?? e?.message ?? e ?? "");
  const code = e?.code ?? e?.cause?.code;
  if (code === 4001 || code === "ACTION_REJECTED" || /user rejected|rejected the request|user denied|declined|cancel/i.test(msg) || e?.name === "WalletSignTransactionError" && /reject/i.test(msg)) {
    return "You cancelled the request in your wallet. Nothing was sent.";
  }
  if (/insufficient funds|exceeds the balance|insufficient lamports|0x1\b/i.test(msg)) return "Insufficient balance to cover the amount plus network fees.";
  if (/blockhash not found|block height exceeded|expired/i.test(msg)) return "The transaction expired before it was confirmed. Nothing was spent — please get a fresh quote and try again.";
  if (/chain.*not configured|switch.*chain/i.test(msg)) return "Please switch your wallet to the required network and try again.";
  return msg.length > 220 ? msg.slice(0, 220) + "…" : msg || "The wallet could not complete the request.";
}

export interface SolanaCtx { wallet: WalletContextState; connection: Connection }

function hexToBytes(hex: string): Uint8Array {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

/** ERC-20 allowance handling (deBridge). Returns true if an approval transaction was sent+confirmed. */
export async function approveIfNeeded(plan: TransactionPlan, owner: `0x${string}`, onStage?: (s: string) => void): Promise<boolean> {
  if (plan.kind !== "evm" || !plan.approval) return false;
  const { token, spender, amount } = plan.approval;
  const need = BigInt(amount);
  const allowance = await readContract(wagmiConfig, {
    chainId: plan.chainId as any, abi: erc20Abi, address: token as `0x${string}`, functionName: "allowance", args: [owner, spender as `0x${string}`],
  });
  if (allowance >= need) return false;
  onStage?.("Approve the token spend in your wallet…");
  // Small buffer: deBridge may refresh operating expenses between quote and final transaction.
  const approveAmount = (need * 102n) / 100n;
  const hash = await writeContract(wagmiConfig, {
    chainId: plan.chainId as any, abi: erc20Abi, address: token as `0x${string}`, functionName: "approve", args: [spender as `0x${string}`, approveAmount],
  });
  const receipt = await waitForTransactionReceipt(wagmiConfig, { hash, chainId: plan.chainId as any });
  if (receipt.status !== "success") throw new Error("The token approval transaction failed.");
  return true;
}

export async function sendEvmPlan(plan: Extract<TransactionPlan, { kind: "evm" }>): Promise<`0x${string}`> {
  const acct = getAccount(wagmiConfig);
  if (acct.chainId !== plan.chainId) await switchChain(wagmiConfig, { chainId: plan.chainId as any });
  return sendTransaction(wagmiConfig, {
    chainId: plan.chainId as any,
    to: plan.to as `0x${string}`,
    data: plan.data as `0x${string}`,
    value: BigInt(plan.value),
  });
}

export async function waitEvmConfirmation(hash: `0x${string}`, chainId: number): Promise<void> {
  const receipt = await waitForTransactionReceipt(wagmiConfig, { hash, chainId: chainId as any, timeout: 5 * 60_000 });
  if (receipt.status !== "success") throw new Error("The source transaction reverted on-chain. You were not charged the bridge amount; only network gas was used.");
}

export async function sendSolanaPlan(plan: Extract<TransactionPlan, { kind: "solana-versioned" | "solana-transfer" }>, ctx: SolanaCtx): Promise<string> {
  const { wallet, connection } = ctx;
  if (!wallet.publicKey || !wallet.sendTransaction) throw new Error("Solana wallet is not connected.");
  const latest = await connection.getLatestBlockhash("confirmed");

  if (plan.kind === "solana-versioned") {
    const tx = VersionedTransaction.deserialize(hexToBytes(plan.dataHex));
    // deBridge docs: refresh the blockhash before signing.
    (tx.message as any).recentBlockhash = latest.blockhash;
    return wallet.sendTransaction(tx, connection, { skipPreflight: false, maxRetries: 3 });
  }

  const owner = wallet.publicKey;
  const to = new PublicKey(plan.to);
  const tx = new Transaction({ feePayer: owner, recentBlockhash: latest.blockhash });
  const amount = BigInt(plan.amount);
  if (!plan.mint) {
    tx.add(SystemProgram.transfer({ fromPubkey: owner, toPubkey: to, lamports: amount }));
  } else {
    const mint = new PublicKey(plan.mint);
    const srcAta = getAssociatedTokenAddressSync(mint, owner);
    const dstAta = getAssociatedTokenAddressSync(mint, to, true);
    tx.add(
      createAssociatedTokenAccountIdempotentInstruction(owner, dstAta, to, mint),
      createTransferCheckedInstruction(srcAta, mint, dstAta, owner, amount, plan.decimals),
    );
  }
  return wallet.sendTransaction(tx, connection, { maxRetries: 3 });
}

/** Polls until the signature is confirmed. Throws if the tx failed on-chain or never landed. */
export async function waitSolanaConfirmation(sig: string, connection: Connection, timeoutMs = 120_000): Promise<void> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const { value } = await connection.getSignatureStatuses([sig], { searchTransactionHistory: true });
    const s = value[0];
    if (s?.err) throw new Error("The Solana transaction failed on-chain. Only the network fee was spent.");
    if (s && (s.confirmationStatus === "confirmed" || s.confirmationStatus === "finalized")) return;
    await new Promise((r) => setTimeout(r, 2000));
  }
  throw new Error("The Solana transaction was not confirmed in time. Check the signature in a Solana explorer before retrying.");
}
