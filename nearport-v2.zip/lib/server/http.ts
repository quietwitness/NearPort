import "server-only";
import { ProviderError } from "../providers/types";

/** fetch JSON with a hard timeout. Never forwards caller-supplied URLs; callers build URLs from config only. */
export async function fetchJson(url: string, init: RequestInit = {}, timeoutMs = 15_000): Promise<{ ok: boolean; status: number; data: any }> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: ctrl.signal, cache: "no-store" });
    const text = await res.text();
    let data: any = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = { raw: text.slice(0, 500) }; }
    return { ok: res.ok, status: res.status, data };
  } catch (e: any) {
    if (e?.name === "AbortError") throw new ProviderError("The provider did not respond in time. Please try again.", 504);
    throw new ProviderError("Could not reach the provider. Please try again.", 502);
  } finally {
    clearTimeout(t);
  }
}

export function providerMessage(data: any, fallback: string): string {
  const m = data?.message ?? data?.errorMessage ?? data?.error ?? data?.raw;
  return typeof m === "string" && m ? m.slice(0, 300) : fallback;
}
