import "server-only";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { ProviderError } from "../providers/types";
import { ConfigError } from "./config";
import { clientIp, rateLimit } from "./ratelimit";

export function json(data: unknown, status = 200, headers?: Record<string, string>) {
  return NextResponse.json(data, { status, headers: { "Cache-Control": "no-store", ...headers } });
}

export function errorResponse(e: unknown) {
  if (e instanceof ConfigError) return json({ error: e.message, code: "CONFIG_ERROR" }, 503);
  if (e instanceof ZodError) {
    const i = e.issues[0];
    return json({ error: `Invalid request: ${i?.path.join(".") || "body"} — ${i?.message ?? "invalid"}`, code: "INVALID_REQUEST" }, 400);
  }
  if (e instanceof ProviderError) return json({ error: e.message, code: "PROVIDER_ERROR" }, e.status >= 400 && e.status < 600 ? e.status : 502);
  console.error("[api] unexpected error", e instanceof Error ? e.message : e);
  return json({ error: "Something went wrong. Please try again.", code: "INTERNAL" }, 500);
}

/** Same-origin guard for state-changing endpoints (blocks other sites from using our API + provider quota). */
export function assertSameOrigin(req: Request) {
  const origin = req.headers.get("origin");
  if (!origin) return;
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  let ok = false;
  try { ok = new URL(origin).host === host; } catch { ok = false; }
  if (!ok) throw new ProviderError("Cross-origin requests are not allowed.", 403);
}

export async function readJson(req: Request, maxBytes = 8_192): Promise<unknown> {
  const text = await req.text();
  if (text.length > maxBytes) throw new ProviderError("Request too large.", 413);
  try { return JSON.parse(text); } catch { throw new ProviderError("Request body must be valid JSON.", 400); }
}

export function limit(req: Request, bucket: string, max: number, windowMs = 60_000) {
  const r = rateLimit(`${bucket}:${clientIp(req)}`, max, windowMs);
  if (!r.ok) throw new ProviderError(`Too many requests. Try again in ${r.retryAfterSec}s.`, 429);
}
