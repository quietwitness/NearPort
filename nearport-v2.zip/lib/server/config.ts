import "server-only";
import { isValidEvmAddress, isValidNearAccount, isValidSolanaAddress } from "../validation";

/** NearPort platform fee: 0.10% = 10 bps. Charged only through provider-native fee mechanisms. */
export const PLATFORM_FEE_BPS = 10;
export const PLATFORM_FEE_PERCENT = "0.10%";
/** deBridge takes affiliateFeePercent as a percent (0.1 = 0.1%), not bps. */
export const PLATFORM_FEE_PERCENT_DEBRIDGE = String(PLATFORM_FEE_BPS / 100);

export class ConfigError extends Error {
  readonly code = "CONFIG_ERROR";
  constructor(message: string) {
    super(message);
  }
}

function env(name: string): string {
  return (process.env[name] ?? "").trim();
}

export interface ServerConfig {
  oneClick: { baseUrl: string; jwt: string };
  debridge: { baseUrl: string; statsUrl: string; referralCode: string; accessToken: string; solanaAffiliateRecipient: string };
  fees: { nearAccount: string; solanaAddress: string; evmAddress: string };
}

/** Read lazily so tests / runtime env changes are honoured. Never imported by client code (server-only). */
export function getServerConfig(): ServerConfig {
  return {
    oneClick: {
      baseUrl: (env("ONECLICK_BASE_URL") || "https://1click.chaindefuser.com").replace(/\/$/, ""),
      jwt: env("ONECLICK_JWT"),
    },
    debridge: {
      baseUrl: (env("DEBRIDGE_BASE_URL") || "https://dln.debridge.finance/v1.0").replace(/\/$/, ""),
      statsUrl: (env("DEBRIDGE_STATS_URL") || "https://dln-api.debridge.finance").replace(/\/$/, ""),
      referralCode: env("DEBRIDGE_REFERRAL_CODE"),
      accessToken: env("DEBRIDGE_ACCESS_TOKEN"),
      solanaAffiliateRecipient: env("DEBRIDGE_SOLANA_AFFILIATE_RECIPIENT"),
    },
    fees: {
      nearAccount: env("FEE_NEAR_ACCOUNT"),
      solanaAddress: env("FEE_SOLANA_ADDRESS"),
      evmAddress: env("FEE_EVM_ADDRESS"),
    },
  };
}

/** NEAR Intents: fee recipient (NEAR account). Throws a clear ConfigError if missing/invalid. */
export function requireNearFeeRecipient(cfg = getServerConfig()): string {
  const v = cfg.fees.nearAccount;
  if (!v) throw new ConfigError("FEE_NEAR_ACCOUNT is not configured. NearPort will not quote NEAR routes without a fee recipient.");
  if (!isValidNearAccount(v)) throw new ConfigError("FEE_NEAR_ACCOUNT is not a valid NEAR account id.");
  return v;
}

/**
 * deBridge: the affiliate beneficiary must live on the ORIGIN chain (Solana public key or EVM address).
 * Fees are only enabled when everything deBridge needs is configured — never silently skipped.
 */
export function requireDebridgeAffiliate(sourceFamily: "evm" | "solana", cfg = getServerConfig()): { recipient: string; referralCode: string } {
  if (!cfg.debridge.referralCode) {
    throw new ConfigError(
      "DEBRIDGE_REFERRAL_CODE is not configured. deBridge affiliate fees require a referral code (generate one at app.debridge.com/refer). Routes via deBridge are disabled until it is set.",
    );
  }
  if (sourceFamily === "evm") {
    const r = cfg.fees.evmAddress;
    if (!r) throw new ConfigError("FEE_EVM_ADDRESS is not configured; EVM-source deBridge routes are disabled.");
    if (!isValidEvmAddress(r)) throw new ConfigError("FEE_EVM_ADDRESS is not a valid EVM address.");
    return { recipient: r, referralCode: cfg.debridge.referralCode };
  }
  const r = cfg.debridge.solanaAffiliateRecipient;
  if (!r) {
    throw new ConfigError(
      "DEBRIDGE_SOLANA_AFFILIATE_RECIPIENT is not configured; Solana-source deBridge routes are disabled until the Solana affiliate beneficiary is set (a Solana public key; fees are withdrawn manually via the DLN program).",
    );
  }
  if (!isValidSolanaAddress(r)) throw new ConfigError("DEBRIDGE_SOLANA_AFFILIATE_RECIPIENT is not a valid Solana public key.");
  return { recipient: r, referralCode: cfg.debridge.referralCode };
}
