export type ChainKey = "solana" | "ethereum" | "base" | "arbitrum" | "near";
export type ChainFamily = "solana" | "evm" | "near";

export interface ChainInfo {
  key: ChainKey;
  name: string;
  family: ChainFamily;
  /** EVM chain id (EVM only). */
  evmChainId?: number;
  /** deBridge DLN internal chain id. NEAR is not a deBridge chain. */
  debridgeChainId?: number;
  /** Values NEAR Intents 1Click uses in `blockchain` on /v0/tokens (accepts aliases defensively). */
  oneClickBlockchains: string[];
  nativeSymbol: string;
  nativeDecimals: number;
  explorerTx?: (hash: string) => string;
}

export const CHAINS: Record<ChainKey, ChainInfo> = {
  solana: {
    key: "solana", name: "Solana", family: "solana", debridgeChainId: 7565164,
    oneClickBlockchains: ["sol", "solana"], nativeSymbol: "SOL", nativeDecimals: 9,
    explorerTx: (h) => `https://solscan.io/tx/${h}`,
  },
  ethereum: {
    key: "ethereum", name: "Ethereum", family: "evm", evmChainId: 1, debridgeChainId: 1,
    oneClickBlockchains: ["eth", "ethereum"], nativeSymbol: "ETH", nativeDecimals: 18,
    explorerTx: (h) => `https://etherscan.io/tx/${h}`,
  },
  base: {
    key: "base", name: "Base", family: "evm", evmChainId: 8453, debridgeChainId: 8453,
    oneClickBlockchains: ["base"], nativeSymbol: "ETH", nativeDecimals: 18,
    explorerTx: (h) => `https://basescan.org/tx/${h}`,
  },
  arbitrum: {
    key: "arbitrum", name: "Arbitrum", family: "evm", evmChainId: 42161, debridgeChainId: 42161,
    oneClickBlockchains: ["arb", "arbitrum"], nativeSymbol: "ETH", nativeDecimals: 18,
    explorerTx: (h) => `https://arbiscan.io/tx/${h}`,
  },
  near: {
    key: "near", name: "NEAR", family: "near",
    oneClickBlockchains: ["near"], nativeSymbol: "NEAR", nativeDecimals: 24,
    explorerTx: (h) => `https://nearblocks.io/txns/${h}`,
  },
};

/** Chains a user can send FROM. Add new EVM networks here + in lib/wallet/evm-config.ts. */
export const SOURCE_CHAINS: ChainKey[] = ["solana", "ethereum", "base", "arbitrum"];
/** Chains a user can send TO. */
export const DESTINATION_CHAINS: ChainKey[] = ["near", "solana", "ethereum", "base", "arbitrum"];

export function isChainKey(v: unknown): v is ChainKey {
  return typeof v === "string" && v in CHAINS;
}
export function chainByEvmId(id: number): ChainInfo | undefined {
  return Object.values(CHAINS).find((c) => c.evmChainId === id);
}
