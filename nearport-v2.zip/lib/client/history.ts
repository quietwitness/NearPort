"use client";
import { useEffect, useState } from "react";
import type { ChainKey } from "../chains";
import type { NormalizedStatusCode, ProviderId } from "../providers/types";

/**
 * Local-only transaction history (browser localStorage). Holds public data only: chain, amounts,
 * public addresses, tx hashes and provider tracking ids. No keys, no seed phrases, nothing server-side.
 */
export interface HistoryItem {
  id: string;
  createdAt: number;
  updatedAt: number;
  provider: ProviderId;
  sourceChain: ChainKey;
  destinationChain: ChainKey;
  sourceSymbol: string;
  sourceDecimals: number;
  destinationSymbol: string;
  destinationDecimals: number;
  amountIn: string;
  estimatedOut: string;
  sender: string;
  recipient: string;
  txHash?: string;
  trackingId?: string;
  status: NormalizedStatusCode | "submitted";
  rawStatus?: string;
  destinationTxHash?: string;
  error?: string;
}

const KEY = "nearport:history:v1";
const EVENT = "nearport:history";
const MAX = 50;

export const TERMINAL: ReadonlyArray<HistoryItem["status"]> = ["complete", "refunded", "failed"];

export function loadHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(KEY);
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch { return []; }
}

function save(items: HistoryItem[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(items.slice(0, MAX)));
    window.dispatchEvent(new Event(EVENT));
  } catch { /* storage unavailable: history is best-effort */ }
}

export function upsertHistory(item: HistoryItem) {
  const items = loadHistory();
  const i = items.findIndex((x) => x.id === item.id);
  const next = { ...item, updatedAt: Date.now() };
  if (i >= 0) items[i] = next; else items.unshift(next);
  save(items);
}

export function patchHistory(id: string, patch: Partial<HistoryItem>) {
  const items = loadHistory();
  const i = items.findIndex((x) => x.id === id);
  if (i < 0) return;
  items[i] = { ...items[i], ...patch, updatedAt: Date.now() };
  save(items);
}

export function clearHistory() { save([]); }

export function useHistory(): HistoryItem[] {
  const [items, setItems] = useState<HistoryItem[]>([]);
  useEffect(() => {
    const read = () => setItems(loadHistory());
    read();
    window.addEventListener(EVENT, read);
    window.addEventListener("storage", read);
    return () => { window.removeEventListener(EVENT, read); window.removeEventListener("storage", read); };
  }, []);
  return items;
}
