import type { BuildResult, NormalizedQuote, NormalizedStatus, ProviderId } from "../providers/types";
import type { TokenInfo } from "../tokens";

export class ApiError extends Error {
  constructor(message: string, public code?: string, public status?: number) { super(message); }
}

async function call<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, { ...init, headers: { "Content-Type": "application/json" }, cache: "no-store" });
  } catch {
    throw new ApiError("Network error. Check your connection and try again.");
  }
  let data: any = null;
  try { data = await res.json(); } catch { /* ignore */ }
  if (!res.ok) throw new ApiError(data?.error ?? `Request failed (${res.status})`, data?.code, res.status);
  return data as T;
}

export interface QuotePayload {
  sourceChain: string;
  destinationChain: string;
  sourceToken: { symbol: string; decimals: number; address: string | null; assetId?: string };
  destinationToken: { symbol: string; decimals: number; address: string | null; assetId?: string };
  amount: string;
  slippageBps: number;
  sender?: string;
  recipient?: string;
}

export const api = {
  tokens: () => call<{ tokens: TokenInfo[] }>("/api/tokens").then((r) => r.tokens),
  health: () => call<Record<"nearIntents" | "debridgeEvm" | "debridgeSolana", { ready: boolean; reason?: string }>>("/api/health"),
  quote: (p: QuotePayload) => call<{ quote: NormalizedQuote }>("/api/quote", { method: "POST", body: JSON.stringify(p) }).then((r) => r.quote),
  build: (p: QuotePayload) => call<BuildResult>("/api/build", { method: "POST", body: JSON.stringify(p) }),
  submit: (p: { provider: ProviderId; txHash: string; trackingId: string }) => call<{ ok: true }>("/api/submit", { method: "POST", body: JSON.stringify(p) }),
  status: (p: { provider: ProviderId; trackingId: string; txHash?: string }) =>
    call<{ status: NormalizedStatus }>("/api/status", { method: "POST", body: JSON.stringify(p) }).then((r) => r.status),
};
