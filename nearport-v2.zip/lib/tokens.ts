import type { ChainKey } from "./chains";

export interface TokenInfo {
  chain: ChainKey;
  symbol: string;
  name: string;
  decimals: number;
  /** Contract / mint address. null = native asset of the chain. */
  address: string | null;
  /** NEAR Intents asset id, when known (from /api/tokens). */
  assetId?: string;
}

/**
 * Static token allow-list used for deBridge routes. Only well-known assets are exposed in the UI;
 * add entries here to support more tokens. Addresses are the canonical native-USDC / USDT deployments.
 */
export const STATIC_TOKENS: TokenInfo[] = [
  { chain: "solana", symbol: "SOL", name: "Solana", decimals: 9, address: null },
  { chain: "solana", symbol: "USDC", name: "USD Coin", decimals: 6, address: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v" },
  { chain: "solana", symbol: "USDT", name: "Tether USD", decimals: 6, address: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB" },
  { chain: "ethereum", symbol: "ETH", name: "Ether", decimals: 18, address: null },
  { chain: "ethereum", symbol: "USDC", name: "USD Coin", decimals: 6, address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" },
  { chain: "ethereum", symbol: "USDT", name: "Tether USD", decimals: 6, address: "0xdAC17F958D2ee523a2206206994597C13D831ec7" },
  { chain: "base", symbol: "ETH", name: "Ether", decimals: 18, address: null },
  { chain: "base", symbol: "USDC", name: "USD Coin", decimals: 6, address: "0x833589fCD6eDb6E08f4C7C32D4f71b54bdA02913" },
  { chain: "arbitrum", symbol: "ETH", name: "Ether", decimals: 18, address: null },
  { chain: "arbitrum", symbol: "USDC", name: "USD Coin", decimals: 6, address: "0xaf88d065e77c8cC2239327C5EDb3A432268e5831" },
  { chain: "arbitrum", symbol: "USDT", name: "Tether USD", decimals: 6, address: "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9" },
];

export function staticTokensFor(chain: ChainKey): TokenInfo[] {
  return STATIC_TOKENS.filter((t) => t.chain === chain);
}

/** Symbols we expose from the NEAR Intents token list. */
export const ONECLICK_SYMBOL_ALLOWLIST = new Set(["ETH", "SOL", "NEAR", "WNEAR", "USDC", "USDT"]);
