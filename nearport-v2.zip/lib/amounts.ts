/** Decimal-string <-> base-unit helpers. Never uses floating point. */

export function parseUnits(value: string, decimals: number): bigint {
  const v = value.trim();
  if (!/^\d*\.?\d*$/.test(v) || v === "" || v === ".") throw new Error("Invalid amount");
  const [whole = "0", frac = ""] = v.split(".");
  if (frac.length > decimals) throw new Error(`Too many decimal places (max ${decimals})`);
  const padded = (frac + "0".repeat(decimals)).slice(0, decimals);
  return BigInt(whole || "0") * 10n ** BigInt(decimals) + BigInt(padded || "0");
}

export function formatUnits(value: bigint | string, decimals: number, maxFraction = 6): string {
  const big = typeof value === "bigint" ? value : BigInt(value);
  const neg = big < 0n;
  const abs = neg ? -big : big;
  const base = 10n ** BigInt(decimals);
  const whole = abs / base;
  let frac = (abs % base).toString().padStart(decimals, "0");
  if (frac.length > maxFraction) frac = frac.slice(0, maxFraction);
  frac = frac.replace(/0+$/, "");
  const wholeStr = whole.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${neg ? "-" : ""}${wholeStr}${frac ? "." + frac : ""}`;
}

/** Fee in base units for `bps` basis points of `amount` (rounded down). */
export function bpsOf(amount: bigint, bps: number): bigint {
  return (amount * BigInt(bps)) / 10_000n;
}
