/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
        ],
      },
    ];
  },
  webpack: (config) => {
    // Optional peer deps pulled in by wallet SDKs that we do not use in the browser bundle.
    config.resolve.fallback = { ...config.resolve.fallback, "pino-pretty": false, lokijs: false, encoding: false };
    // wagmi's connectors barrel references Coinbase "Base Account" payment helpers that need optional x402 packages.
    // We do not use those connectors, so stub them out instead of installing unused dependencies.
    config.resolve.alias = { ...config.resolve.alias, "@x402/core": false, "@x402/evm": false, "@x402/svm": false };
    return config;
  },
};
export default nextConfig;
