import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { buildCreateTxParams, debridgeAdapter, mapDebridgeState, planFromTx } from "@/lib/providers/debridge";
import { quoteRequestSchema } from "@/lib/validation";
import { EVM_ADDR, SOL_ADDR, setEnv, solToEth, usdcEthToBase } from "./helpers";

beforeEach(() => setEnv());
afterEach(() => vi.unstubAllGlobals());

const est = (over: any = {}) => ({
  estimation: {
    srcChainTokenIn: { address: "11111111111111111111111111111111", chainId: 7565164, amount: "1005000000", approximateOperatingExpense: "5000000" },
    dstChainTokenOut: { address: "0x0000000000000000000000000000000000000000", chainId: 1, amount: "5", recommendedAmount: "4" },
  },
  tx: { data: "abcd" }, orderId: "0x" + "ab".repeat(32), fixFee: "0", ...over,
});

describe("deBridge params", () => {
  it("uses percent (0.1) not bps, origin-chain beneficiary, referral code", () => {
    const p = buildCreateTxParams(quoteRequestSchema.parse(usdcEthToBase()), { build: true });
    expect(p.get("affiliateFeePercent")).toBe("0.1");
    expect(p.get("affiliateFeeRecipient")).toBe(EVM_ADDR);
    expect(p.get("referralCode")).toBe("12345");
    expect(p.get("srcChainId")).toBe("1");
    expect(p.get("dstChainId")).toBe("8453");
    expect(p.get("dstChainTokenOutAmount")).toBe("auto");
    expect(p.get("dstChainOrderAuthorityAddress")).toBe(EVM_ADDR);
  });
  it("Solana source uses the Solana beneficiary", () => {
    const p = buildCreateTxParams(quoteRequestSchema.parse(solToEth()), { build: false });
    expect(p.get("affiliateFeeRecipient")).toBe(SOL_ADDR);
    expect(p.get("srcChainId")).toBe("7565164");
    expect(p.get("srcChainTokenIn")).toBe("11111111111111111111111111111111");
    expect(p.has("senderAddress")).toBe(false); // estimation only
  });
  it("blocks Solana-source routes until the Solana affiliate is configured (no silent fee skip)", () => {
    setEnv({ DEBRIDGE_SOLANA_AFFILIATE_RECIPIENT: undefined });
    expect(() => buildCreateTxParams(quoteRequestSchema.parse(solToEth()), { build: false })).toThrow(/DEBRIDGE_SOLANA_AFFILIATE_RECIPIENT/);
    // EVM routes still work
    expect(() => buildCreateTxParams(quoteRequestSchema.parse(usdcEthToBase()), { build: false })).not.toThrow();
  });
  it("blocks all routes without a referral code", () => {
    setEnv({ DEBRIDGE_REFERRAL_CODE: undefined });
    expect(() => buildCreateTxParams(quoteRequestSchema.parse(usdcEthToBase()), { build: false })).toThrow(/DEBRIDGE_REFERRAL_CODE/);
  });
});

describe("deBridge adapter (fetch mocked)", () => {
  it("normalizes a quote and includes the 10 bps platform fee line", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify(est()), { status: 200 })));
    const q = await debridgeAdapter.getQuote(quoteRequestSchema.parse(solToEth()));
    expect(q.fees.find((f) => f.platform)?.amount).toBe("1000000"); // 10bps of 1e9
    expect(q.amountOut).toBe("4");
    expect(q.trackingId).toBe("0x" + "ab".repeat(32));
  });
  it("rejects a response for a different route/token", async () => {
    const bad = est(); bad.estimation.dstChainTokenOut.chainId = 8453;
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify(bad), { status: 200 })));
    await expect(debridgeAdapter.getQuote(quoteRequestSchema.parse(solToEth()))).rejects.toThrow(/different route/);
  });
  it("shows provider errors readably", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({ errorId: "ERROR_LOW_GIVE_AMOUNT" }), { status: 400 })));
    await expect(debridgeAdapter.getQuote(quoteRequestSchema.parse(solToEth()))).rejects.toThrow(/too small/);
  });
  it("Solana build returns a versioned-tx plan; ERC-20 build returns approval info", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify(est()), { status: 200 })));
    const r = await debridgeAdapter.buildTransaction(quoteRequestSchema.parse(solToEth()));
    expect(r.plan).toEqual({ kind: "solana-versioned", dataHex: "abcd" });
    const req = quoteRequestSchema.parse(usdcEthToBase());
    const plan: any = planFromTx(req, { amountIn: "100500000" } as any, { to: EVM_ADDR, data: "0xdead", value: "0x10" });
    expect(plan.value).toBe("16");
    expect(plan.approval).toEqual({ token: req.sourceToken.address, spender: EVM_ADDR, amount: "100500000" });
  });
});

describe("deBridge status", () => {
  it("shows complete only for Fulfilled / SentUnlock / ClaimedUnlock", () => {
    for (const s of ["Fulfilled", "SentUnlock", "ClaimedUnlock"]) expect(mapDebridgeState(s).code).toBe("complete");
    for (const s of ["None", "Created", "garbage"]) expect(mapDebridgeState(s).code).not.toBe("complete");
    for (const s of ["OrderCancelled", "SentOrderCancel", "ClaimedOrderCancel"]) expect(mapDebridgeState(s).code).toBe("refunded");
  });
});
