import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { buildQuoteBody, depositPlan, mapOneClickStatus, nearIntentsAdapter, normalizeOneClickTokens, oneClickAppFeeRequestBps, oneClickFeeSplit } from "@/lib/providers/near-intents";
import { quoteRequestSchema } from "@/lib/validation";
import { EVM_ADDR, NEAR_ACC, SOL_ADDR, setEnv, solToNear } from "./helpers";

beforeEach(() => setEnv());
afterEach(() => vi.unstubAllGlobals());

describe("NEAR Intents fee configuration", () => {
  it("documents the 50/50 split: requesting 10 bps would pay NearPort 5 and charge the user 25", () => {
    const s = oneClickFeeSplit(10);
    expect(s.platformBps).toBe(5);
    expect(s.platformBps + s.providerBps).toBe(25);
  });
  it("requests 2x so NearPort actually receives 10 bps", () => {
    expect(oneClickAppFeeRequestBps()).toBe(20);
    const s = oneClickFeeSplit(20);
    expect(s.platformBps).toBe(10);
    expect(s.providerBps).toBe(20);
  });
  it("honours an explicit override and rejects garbage", () => {
    process.env.ONECLICK_APP_FEE_REQUEST_BPS = "40";
    expect(oneClickAppFeeRequestBps()).toBe(40);
    process.env.ONECLICK_APP_FEE_REQUEST_BPS = "abc";
    expect(() => oneClickAppFeeRequestBps()).toThrow(/ONECLICK_APP_FEE_REQUEST_BPS/);
  });
  it("puts the configured NEAR fee recipient in appFees (never a client value)", () => {
    const { body } = buildQuoteBody(quoteRequestSchema.parse(solToNear()), true);
    expect(body.appFees).toEqual([{ recipient: NEAR_ACC, fee: 20 }]);
    expect(body.dry).toBe(true);
    expect(body.swapType).toBe("EXACT_INPUT");
    expect(body.refundTo).toBe(SOL_ADDR);
  });
  it("fails with a clear config error when the fee recipient is missing", () => {
    setEnv({ FEE_NEAR_ACCOUNT: undefined });
    expect(() => buildQuoteBody(quoteRequestSchema.parse(solToNear()), true)).toThrow(/FEE_NEAR_ACCOUNT/);
  });
});

describe("NEAR Intents adapter (fetch mocked)", () => {
  const upstream = { quote: { depositAddress: "9Wy3nQ2dYrSx7pUqJx8bV5gC1eLmHkTt4ZfA6oDsRiP2", amountIn: "1000000000", amountOut: "5000000000000000000000000", minAmountOut: "4950000000000000000000000", timeEstimate: 60, deadline: new Date(Date.now() + 1800_000).toISOString() } };

  it("works without a JWT: no auth header, NearPort keeps full 10 bps, 1Click adds 25", async () => {
    setEnv({ ONECLICK_JWT: undefined });
    const f = vi.fn(async () => new Response(JSON.stringify(upstream), { status: 200 }));
    vi.stubGlobal("fetch", f);
    const q = await nearIntentsAdapter.getQuote(quoteRequestSchema.parse(solToNear()));
    const [, init] = f.mock.calls[0] as any;
    expect(init.headers.Authorization).toBeUndefined();
    expect(JSON.parse(init.body).appFees).toEqual([{ recipient: NEAR_ACC, fee: 10 }]);
    expect(q.fees.find((x) => x.platform)?.amount).toBe("1000000");
    expect(q.fees.find((x) => x.label === "NEAR Intents fee")?.amount).toBe("2500000");
  });
  it("sends the JWT only as a server-side Authorization header and normalizes the quote", async () => {
    const f = vi.fn(async () => new Response(JSON.stringify(upstream), { status: 200 }));
    vi.stubGlobal("fetch", f);
    const q = await nearIntentsAdapter.getQuote(quoteRequestSchema.parse(solToNear()));
    const [url, init] = f.mock.calls[0] as any;
    expect(url).toContain("/v0/quote");
    expect(init.headers.Authorization).toBe("Bearer test-jwt-SECRET");
    expect(q.provider).toBe("near-intents");
    expect(q.platformFeeBps).toBe(10);
    expect(q.fees.find((x) => x.platform)?.amount).toBe("1000000"); // 10 bps of 1 SOL (1e9) = 1e6
    expect(q.fees.find((x) => x.label === "NEAR Intents fee")?.amount).toBe("2000000"); // 20 bps
    expect(JSON.stringify(q)).not.toContain("test-jwt-SECRET");
  });
  it("build returns a deposit plan and refuses a changed input amount", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify(upstream), { status: 200 })));
    const r = await nearIntentsAdapter.buildTransaction(quoteRequestSchema.parse(solToNear()));
    expect(r.plan).toEqual({ kind: "solana-transfer", to: upstream.quote.depositAddress, mint: null, amount: "1000000000", decimals: 9 });
    expect(r.quote.trackingId).toBe(upstream.quote.depositAddress);
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({ quote: { ...upstream.quote, amountIn: "999" } }), { status: 200 })));
    await expect(nearIntentsAdapter.buildTransaction(quoteRequestSchema.parse(solToNear()))).rejects.toThrow(/different input amount/);
  });
  it("surfaces provider errors readably", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({ message: "Amount is too low for bridge" }), { status: 400 })));
    await expect(nearIntentsAdapter.getQuote(quoteRequestSchema.parse(solToNear()))).rejects.toThrow("Amount is too low for bridge");
  });
  it("rejects non-NEAR destinations and missing wallet/recipient", async () => {
    await expect(nearIntentsAdapter.getQuote(quoteRequestSchema.parse(solToNear({ destinationChain: "base" })))).rejects.toThrow();
    await expect(nearIntentsAdapter.getQuote(quoteRequestSchema.parse(solToNear({ sender: undefined })))).rejects.toThrow(/Connect a wallet/);
  });
});

describe("deposit plans + status mapping + token normalization", () => {
  it("EVM native and ERC-20 deposit plans", () => {
    const native = quoteRequestSchema.parse({ ...solToNear(), sourceChain: "base", sender: EVM_ADDR, sourceToken: { symbol: "ETH", decimals: 18, address: null, assetId: "x" } });
    expect(depositPlan(native, EVM_ADDR, "5")).toEqual({ kind: "evm", chainId: 8453, to: EVM_ADDR, data: "0x", value: "5" });
    const erc = quoteRequestSchema.parse({ ...solToNear(), sourceChain: "ethereum", sender: EVM_ADDR, sourceToken: { symbol: "USDC", decimals: 6, address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", assetId: "x" } });
    const p: any = depositPlan(erc, EVM_ADDR, "1000000");
    expect(p.to).toBe("0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48");
    expect(p.data.startsWith("0xa9059cbb")).toBe(true); // transfer(address,uint256)
    expect(p.value).toBe("0");
  });
  it("refuses invalid deposit addresses", () => {
    expect(() => depositPlan(quoteRequestSchema.parse(solToNear()), "not-an-address", "1")).toThrow();
  });
  it("only reports success for SUCCESS", () => {
    expect(mapOneClickStatus({ status: "SUCCESS", swapDetails: { destinationChainTxHashes: [{ hash: "abc" }] } })).toMatchObject({ code: "complete", destinationTxHash: "abc" });
    for (const s of ["PENDING_DEPOSIT", "KNOWN_DEPOSIT_TX", "PROCESSING", "INCOMPLETE_DEPOSIT", "FAILED", "REFUNDED", "???"]) expect(mapOneClickStatus({ status: s }).code).not.toBe("complete");
    expect(mapOneClickStatus({ status: "REFUNDED" }).code).toBe("refunded");
  });
  it("normalizes tokens and drops wrapped/unknown variants", () => {
    const t = normalizeOneClickTokens([
      { assetId: "nep141:sol.omft.near", blockchain: "sol", symbol: "SOL", decimals: 9 },
      { assetId: "nep141:sol-5ce3.omft.near", blockchain: "sol", symbol: "USDC", decimals: 6, contractAddress: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v" },
      { assetId: "nep141:sol-eth.omft.near", blockchain: "sol", symbol: "ETH", decimals: 8, contractAddress: "7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs" }, // wrapped ETH on Solana
      { assetId: "nep141:eth.omft.near", blockchain: "eth", symbol: "ETH", decimals: 18 },
      { assetId: "nep141:eth-0xdead.omft.near", blockchain: "eth", symbol: "USDC", decimals: 6 }, // no contract address -> unusable
      { assetId: "nep141:wrap.near", blockchain: "near", symbol: "wNEAR", decimals: 24 },
      { assetId: "nep141:doge", blockchain: "doge", symbol: "DOGE", decimals: 8 },
    ]);
    expect(t.map((x) => `${x.chain}:${x.symbol}`)).toEqual(["solana:SOL", "solana:USDC", "ethereum:ETH", "near:NEAR"]);
  });
});
