import { describe, expect, it } from "vitest";
import { getRoute } from "@/lib/routing/engine";

describe("route engine", () => {
  it("routes NEAR destinations to NEAR Intents", () => {
    for (const s of ["solana", "ethereum", "base", "arbitrum"] as const)
      expect(getRoute({ sourceChain: s, destinationChain: "near" })).toEqual({ ok: true, provider: "near-intents" });
  });
  it("routes other pairs to deBridge", () => {
    expect(getRoute({ sourceChain: "solana", destinationChain: "ethereum" })).toEqual({ ok: true, provider: "debridge" });
    expect(getRoute({ sourceChain: "solana", destinationChain: "base" })).toEqual({ ok: true, provider: "debridge" });
    expect(getRoute({ sourceChain: "ethereum", destinationChain: "arbitrum" })).toEqual({ ok: true, provider: "debridge" });
    expect(getRoute({ sourceChain: "base", destinationChain: "solana" })).toEqual({ ok: true, provider: "debridge" });
  });
  it("fails gracefully on unsupported routes", () => {
    expect(getRoute({ sourceChain: "near", destinationChain: "solana" }).ok).toBe(false);
    expect(getRoute({ sourceChain: "solana", destinationChain: "solana" }).ok).toBe(false);
    expect(getRoute({ sourceChain: "bitcoin" as any, destinationChain: "near" }).ok).toBe(false);
  });
});
