export const SOL_ADDR = "J8eGoHL9vvae95SeGKzSnfihir96fPLPecjGXJkC5YLZ";
export const EVM_ADDR = "0x3AB86BbE3b3C3c22F5cab4D884C270277E8A022d";
export const NEAR_ACC = "1d354f9399e1988ba0d31768a449767d11d48cb0f4498fa5cf87b81cc043bc07";

export function setEnv(over: Record<string, string | undefined> = {}) {
  const base: Record<string, string> = {
    ONECLICK_JWT: "test-jwt-SECRET",
    FEE_NEAR_ACCOUNT: NEAR_ACC, FEE_SOLANA_ADDRESS: SOL_ADDR, FEE_EVM_ADDRESS: EVM_ADDR,
    DEBRIDGE_REFERRAL_CODE: "12345", DEBRIDGE_SOLANA_AFFILIATE_RECIPIENT: SOL_ADDR,
  };
  for (const k of ["ONECLICK_JWT", "FEE_NEAR_ACCOUNT", "FEE_SOLANA_ADDRESS", "FEE_EVM_ADDRESS", "DEBRIDGE_REFERRAL_CODE", "DEBRIDGE_SOLANA_AFFILIATE_RECIPIENT", "ONECLICK_APP_FEE_REQUEST_BPS"]) delete process.env[k];
  for (const [k, v] of Object.entries({ ...base, ...over })) if (v !== undefined) process.env[k] = v;
}

export const solToNear = (over: any = {}) => ({
  sourceChain: "solana", destinationChain: "near",
  sourceToken: { symbol: "SOL", decimals: 9, address: null, assetId: "nep141:sol.omft.near" },
  destinationToken: { symbol: "NEAR", decimals: 24, address: null, assetId: "nep141:wrap.near" },
  amount: "1000000000", slippageBps: 100, sender: SOL_ADDR, recipient: "alice.near", ...over,
});
export const solToEth = (over: any = {}) => ({
  sourceChain: "solana", destinationChain: "ethereum",
  sourceToken: { symbol: "SOL", decimals: 9, address: null },
  destinationToken: { symbol: "ETH", decimals: 18, address: null },
  amount: "1000000000", slippageBps: 100, sender: SOL_ADDR, recipient: EVM_ADDR, ...over,
});
export const usdcEthToBase = (over: any = {}) => ({
  sourceChain: "ethereum", destinationChain: "base",
  sourceToken: { symbol: "USDC", decimals: 6, address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" },
  destinationToken: { symbol: "USDC", decimals: 6, address: "0x833589fCD6eDb6E08f4C7C32D4f71b54bdA02913" },
  amount: "100000000", slippageBps: 100, sender: EVM_ADDR, recipient: EVM_ADDR, ...over,
});
