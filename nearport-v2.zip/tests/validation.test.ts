import { describe, expect, it } from "vitest";
import { formatUnits, parseUnits, bpsOf } from "@/lib/amounts";
import { isValidEvmAddress, isValidNearAccount, isValidSolanaAddress, isValidTxHash, quoteRequestSchema, semanticQuoteErrors } from "@/lib/validation";
import { EVM_ADDR, NEAR_ACC, SOL_ADDR, solToNear } from "./helpers";

describe("address validation", () => {
  it("accepts valid addresses", () => {
    expect(isValidSolanaAddress(SOL_ADDR)).toBe(true);
    expect(isValidEvmAddress(EVM_ADDR)).toBe(true);
    expect(isValidNearAccount(NEAR_ACC)).toBe(true);
    expect(isValidNearAccount("alice.near")).toBe(true);
    expect(isValidNearAccount("sub.alice.near")).toBe(true);
  });
  it("rejects invalid addresses", () => {
    expect(isValidSolanaAddress("0x123")).toBe(false);
    expect(isValidSolanaAddress("J8eGoHL9vvae95SeGKzSnfihir96fPLPecjGXJkC5YL0")).toBe(false); // 0 is not base58
    expect(isValidSolanaAddress("J8eGoHL9vvae95SeGKzSnfihir96")).toBe(false); // too short
    expect(isValidEvmAddress("0x3AB86BbE3b3C3c22F5cab4D884C270277E8A022")).toBe(false);
    expect(isValidEvmAddress("3AB86BbE3b3C3c22F5cab4D884C270277E8A022d")).toBe(false);
    expect(isValidNearAccount("Alice.near")).toBe(false);
    expect(isValidNearAccount("a")).toBe(false);
    expect(isValidNearAccount("alice..near")).toBe(false);
    expect(isValidNearAccount("alice near")).toBe(false);
    expect(isValidNearAccount("")).toBe(false);
  });
  it("validates tx hashes", () => {
    expect(isValidTxHash("0x" + "a".repeat(64))).toBe(true);
    expect(isValidTxHash("0x123")).toBe(false);
    expect(isValidTxHash("5".repeat(88))).toBe(true);
  });
});

describe("amount math", () => {
  it("parses and formats without floats", () => {
    expect(parseUnits("1.5", 9)).toBe(1_500_000_000n);
    expect(parseUnits("0.000000001", 9)).toBe(1n);
    expect(() => parseUnits("0.0000000001", 9)).toThrow();
    expect(() => parseUnits("abc", 9)).toThrow();
    expect(() => parseUnits("-1", 9)).toThrow();
    expect(() => parseUnits("", 9)).toThrow();
    expect(formatUnits(1_500_000_000n, 9)).toBe("1.5");
    expect(formatUnits("1234567890000000000000", 18)).toBe("1,234.56789");
  });
  it("computes 10 bps", () => { expect(bpsOf(1_000_000n, 10)).toBe(1_000n); });
});

describe("quote request schema", () => {
  it("accepts a valid request and defaults slippage", () => {
    const { slippageBps, ...rest } = solToNear();
    expect(quoteRequestSchema.parse(rest).slippageBps).toBe(100);
  });
  it("rejects unknown keys (no arbitrary provider params)", () => {
    expect(() => quoteRequestSchema.parse({ ...solToNear(), affiliateFeePercent: "0" })).toThrow();
    expect(() => quoteRequestSchema.parse({ ...solToNear(), appFees: [] })).toThrow();
  });
  it("rejects bad chains, amounts and slippage", () => {
    expect(() => quoteRequestSchema.parse({ ...solToNear(), sourceChain: "bitcoin" })).toThrow();
    expect(() => quoteRequestSchema.parse({ ...solToNear(), amount: "1.5" })).toThrow();
    expect(() => quoteRequestSchema.parse({ ...solToNear(), amount: "-5" })).toThrow();
    expect(() => quoteRequestSchema.parse({ ...solToNear(), slippageBps: 5000 })).toThrow();
    expect(() => quoteRequestSchema.parse({ ...solToNear(), slippageBps: 0 })).toThrow();
  });
  it("semantic checks: same chain, zero amount, wrong-family addresses", () => {
    expect(semanticQuoteErrors(quoteRequestSchema.parse(solToNear({ destinationChain: "solana" })), { requireAddresses: false })).toMatch(/differ/);
    expect(semanticQuoteErrors(quoteRequestSchema.parse(solToNear({ amount: "0" })), { requireAddresses: false })).toMatch(/greater than zero/);
    expect(semanticQuoteErrors(quoteRequestSchema.parse(solToNear({ recipient: "Bad Account!" })), { requireAddresses: true })).toMatch(/recipient/i);
    expect(semanticQuoteErrors(quoteRequestSchema.parse(solToNear({ sender: EVM_ADDR })), { requireAddresses: true })).toMatch(/sender/i);
    expect(semanticQuoteErrors(quoteRequestSchema.parse(solToNear()), { requireAddresses: true })).toBeNull();
  });
});
