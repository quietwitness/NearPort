"use client";
import { STEPS } from "@/lib/steps";

export function StepTracker({ step, failed }: { step: number; failed?: boolean }) {
  const pct = Math.round(((step - (failed ? 1 : 0)) / STEPS.length) * 100);
  return (
    <details className="tracker" open={step >= 6}>
      <summary>
        <span>Step {step} of {STEPS.length}: <b>{STEPS[step - 1]}</b>{failed ? " — stopped" : ""}</span>
        <i className="bar"><em style={{ width: `${pct}%` }} className={failed ? "bad" : ""} /></i>
      </summary>
      <ol>
        {STEPS.map((s, i) => {
          const n = i + 1;
          const cls = n < step ? "done" : n === step ? (failed ? "fail" : "now") : "todo";
          return <li key={s} className={cls}><span>{n < step ? "✓" : n}</span>{s}</li>;
        })}
      </ol>
    </details>
  );
}
