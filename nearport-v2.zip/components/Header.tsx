"use client";
import { useWallet } from "@solana/wallet-adapter-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useAccount } from "wagmi";
import { chainByEvmId } from "@/lib/chains";
import { shortAddress } from "@/lib/format";
import { WalletModal } from "./WalletModal";

export function Header() {
  const sol = useWallet();
  const evm = useAccount();
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const chains = mounted && evm.isConnected && evm.chainId ? chainByEvmId(evm.chainId) : undefined;
  const any = mounted && (sol.connected || evm.isConnected);

  return (
    <>
      <header className="topbar">
        <Link className="brand" href="/"><img className="brandlogo" src="/nearport-icon.png" alt="" width={38} height={38} /><span>Near<span>Port</span></span></Link>
        <nav>
          <Link href="/#bridge">Bridge</Link><Link href="/history">History</Link><Link href="/#how">How it works</Link><Link href="/#chains">Supported chains</Link><Link href="/#faq">FAQ</Link>
        </nav>
        <div className="top-actions">
          {any && (
            <div className="wallet-chips">
              {sol.connected && sol.publicKey && <span className="chip" title="Solana"><i className="dot sol" />{shortAddress(sol.publicKey.toBase58())}</span>}
              {evm.isConnected && evm.address && (
                <span className={"chip" + (chains ? "" : " warn")} title="EVM network">
                  <i className="dot evm" />{shortAddress(evm.address)} · {chains?.name ?? "Unsupported network"}
                </span>
              )}
            </div>
          )}
          <button className="connect" onClick={() => setOpen(true)}>{any ? "Wallets" : "Connect wallet"}</button>
        </div>
      </header>
      <WalletModal open={open} onClose={() => setOpen(false)} />
    </>
  );
}
