export function Footer() {
  return (
    <footer>
      <div className="brand"><img className="brandlogo" src="/nearport-icon.png" alt="" width={30} height={30} /><span>Near<span>Port</span></span></div>
      <p>Your gateway to NEAR.</p>
      <small>© 2026 NearPort. Independent application using NEAR Intents and deBridge infrastructure. Not financial advice.</small>
    </footer>
  );
}
