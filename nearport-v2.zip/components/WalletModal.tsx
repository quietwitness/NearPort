"use client";
import { useWallet } from "@solana/wallet-adapter-react";
import { WalletReadyState } from "@solana/wallet-adapter-base";
import { useAccount, useConnect, useDisconnect, useSwitchChain } from "wagmi";
import { CHAINS, chainByEvmId } from "@/lib/chains";
import { isMobileUA, shortAddress } from "@/lib/format";
import { WALLETCONNECT_PROJECT_ID } from "@/lib/wallet/wagmi-config";

export function WalletModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const sol = useWallet();
  const evm = useAccount();
  const { connectors, connectAsync, isPending, error: evmError } = useConnect();
  const { disconnect: evmDisconnect } = useDisconnect();
  const { chains, switchChain } = useSwitchChain();
  if (!open) return null;

  const mobile = isMobileUA();
  const host = typeof window !== "undefined" ? window.location.host + window.location.pathname : "";
  const solWallets = sol.wallets.filter((w) => w.readyState !== WalletReadyState.Unsupported);
  const phantomMissing = !solWallets.some((w) => w.adapter.name === "Phantom" && w.readyState === WalletReadyState.Installed);
  const evmChain = evm.chainId ? chainByEvmId(evm.chainId) : undefined;
  const injectedMissing = connectors.filter((c) => c.type === "injected").length === 0;

  return (
    <div className="modal-backdrop" onClick={onClose} role="presentation">
      <div className="modal" role="dialog" aria-modal="true" aria-label="Connect wallet" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head"><h3>Connect wallet</h3><button className="iconbtn" onClick={onClose} aria-label="Close">✕</button></div>
        <p className="modal-note">NearPort never asks for your seed phrase or private key. Every transaction is signed in your own wallet.</p>

        <h4>Solana</h4>
        {sol.connected && sol.publicKey ? (
          <div className="wallet-row connected">
            <span>{sol.wallet?.adapter.name} · {shortAddress(sol.publicKey.toBase58())}</span>
            <button onClick={() => sol.disconnect()}>Disconnect</button>
          </div>
        ) : (
          <div className="wallet-list">
            {solWallets.map((w) => (
              <button key={w.adapter.name} className="wallet-btn" disabled={sol.connecting}
                onClick={async () => { try { sol.select(w.adapter.name); await w.adapter.connect(); onClose(); } catch { /* user rejected */ } }}>
                {w.adapter.icon && <img src={w.adapter.icon} alt="" width={22} height={22} />}
                <span>{w.adapter.name}</span>
                <small>{w.readyState === WalletReadyState.Installed ? "Detected" : "Not installed"}</small>
              </button>
            ))}
            {mobile && phantomMissing && (
              <a className="wallet-btn" href={`https://phantom.app/ul/browse/${encodeURIComponent("https://" + host)}?ref=${encodeURIComponent("https://" + window.location.host)}`}>
                <span>Open in Phantom app</span><small>Mobile</small>
              </a>
            )}
          </div>
        )}

        <h4>EVM · Ethereum, Base, Arbitrum</h4>
        {evm.isConnected && evm.address ? (
          <>
            <div className="wallet-row connected">
              <span>{evm.connector?.name} · {shortAddress(evm.address)}</span>
              <button onClick={() => evmDisconnect()}>Disconnect</button>
            </div>
            <div className="net-row">
              <span>Network: <b>{evmChain?.name ?? "Unsupported — switch below"}</b></span>
              <div>{chains.map((c) => {
                const k = chainByEvmId(c.id);
                return <button key={c.id} className={"pill" + (evm.chainId === c.id ? " on" : "")} onClick={() => switchChain({ chainId: c.id })}>{k?.name ?? c.name}</button>;
              })}</div>
            </div>
          </>
        ) : (
          <div className="wallet-list">
            {connectors.map((c) => (
              <button key={c.uid} className="wallet-btn" disabled={isPending}
                onClick={async () => { try { await connectAsync({ connector: c }); onClose(); } catch { /* user rejected */ } }}>
                {c.icon && <img src={c.icon} alt="" width={22} height={22} />}
                <span>{c.type === "walletConnect" ? "WalletConnect" : c.name}</span>
                <small>{c.type === "walletConnect" ? "Mobile & QR" : "Browser"}</small>
              </button>
            ))}
            {mobile && injectedMissing && (
              <a className="wallet-btn" href={`https://metamask.app.link/dapp/${host}`}><span>Open in MetaMask app</span><small>Mobile</small></a>
            )}
            {!WALLETCONNECT_PROJECT_ID && <p className="modal-note">WalletConnect is off (no NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID configured). Browser wallets still work.</p>}
            {evmError && <div className="err">{evmError.message.slice(0, 160)}</div>}
          </div>
        )}
        <p className="modal-note small">NEAR: you simply enter your NEAR account as the recipient — no NEAR wallet connection is needed.</p>
      </div>
    </div>
  );
}
