"use client";
import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useAccount, useSwitchChain } from "wagmi";
import { parseUnits } from "@/lib/amounts";
import { CHAINS, ChainKey, DESTINATION_CHAINS, SOURCE_CHAINS } from "@/lib/chains";
import { api, ApiError, QuotePayload } from "@/lib/client/api";
import { HistoryItem, patchHistory, TERMINAL, upsertHistory } from "@/lib/client/history";
import { fmtDuration, fmtFee, fmtToken, shortAddress } from "@/lib/format";
import type { NormalizedQuote, TransactionPlan } from "@/lib/providers/types";
import { getRoute } from "@/lib/routing/engine";
import { activeStep, ExecStage } from "@/lib/steps";
import { staticTokensFor, TokenInfo } from "@/lib/tokens";
import { isValidAddressFor } from "@/lib/validation";
import { approveIfNeeded, humanizeWalletError, sendEvmPlan, sendSolanaPlan, waitEvmConfirmation, waitSolanaConfirmation } from "@/lib/wallet/execute";
import { StepTracker } from "./StepTracker";

const RATE_TOLERANCE_BPS = 50n; // if the final quote is >0.5% worse than the one the user reviewed, stop and ask again
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const coinClass = (c: ChainKey) => (c === "solana" ? "sol" : c === "near" ? "near" : c);
const coinLetter = (c: ChainKey) => ({ solana: "S", ethereum: "Ξ", base: "B", arbitrum: "A", near: "N" })[c];

type Health = Awaited<ReturnType<typeof api.health>>;

export function BridgeWidget() {
  const sol = useWallet();
  const { connection } = useConnection();
  const evm = useAccount();
  const { switchChainAsync } = useSwitchChain();

  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const [sourceChain, setSourceChain] = useState<ChainKey>("solana");
  const [destChain, setDestChain] = useState<ChainKey>("near");
  const [srcSymbol, setSrcSymbol] = useState("SOL");
  const [dstSymbol, setDstSymbol] = useState("NEAR");
  const [amount, setAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [slippageBps, setSlippageBps] = useState(100);

  const [ocTokens, setOcTokens] = useState<TokenInfo[]>([]);
  const [ocError, setOcError] = useState("");
  const [health, setHealth] = useState<Health | null>(null);

  const [quote, setQuote] = useState<NormalizedQuote | null>(null);
  const [now, setNow] = useState(Date.now());
  const [stage, setStage] = useState<ExecStage>("idle");
  const [statusText, setStatusText] = useState("");
  const [error, setError] = useState("");
  const [errorMeta, setErrorMeta] = useState<{ trackingId?: string; txHash?: string }>({});
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ destinationTxHash?: string } | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  useEffect(() => () => abortRef.current?.abort(), []);

  // ---- data loading ----
  useEffect(() => { api.health().then(setHealth).catch(() => undefined); }, []);
  useEffect(() => {
    if (destChain !== "near" || ocTokens.length) return;
    api.tokens().then(setOcTokens).catch((e) => setOcError(e.message || "Could not load NEAR Intents assets."));
  }, [destChain, ocTokens.length]);
  useEffect(() => { if (!quote) return; const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, [quote]);

  // ---- derived ----
  const src = CHAINS[sourceChain], dst = CHAINS[destChain];
  const route = getRoute({ sourceChain, destinationChain: destChain });
  const provider = route.ok ? route.provider : null;

  const srcTokens = useMemo(() => (destChain === "near" ? ocTokens.filter((t) => t.chain === sourceChain) : staticTokensFor(sourceChain)), [destChain, ocTokens, sourceChain]);
  const dstTokens = useMemo(() => (destChain === "near" ? ocTokens.filter((t) => t.chain === "near") : staticTokensFor(destChain)), [destChain, ocTokens]);
  const srcToken = srcTokens.find((t) => t.symbol === srcSymbol) ?? srcTokens[0];
  const dstToken = dstTokens.find((t) => t.symbol === dstSymbol) ?? dstTokens[0];

  const sender = src.family === "solana" ? sol.publicKey?.toBase58() : src.family === "evm" ? evm.address : undefined;
  const walletConnected = mounted && !!sender;
  const evmWrongChain = mounted && src.family === "evm" && evm.isConnected && evm.chainId !== src.evmChainId;

  const providerHealth = provider === "near-intents" ? health?.nearIntents : provider === "debridge" ? (src.family === "solana" ? health?.debridgeSolana : health?.debridgeEvm) : undefined;
  const providerDown = providerHealth && !providerHealth.ready;

  const recipientTrim = recipient.trim();
  const recipientValid = recipientTrim !== "" && isValidAddressFor(dst.family, recipientTrim);
  let amountBase: bigint | null = null;
  let amountError = "";
  if (amount.trim() && srcToken) {
    try { amountBase = parseUnits(amount, srcToken.decimals); if (amountBase <= 0n) { amountBase = null; amountError = "Enter an amount greater than zero."; } }
    catch (e: any) { amountError = e.message; }
  }

  const step = activeStep({ connected: walletConnected, hasAmount: !!amountBase, hasRecipient: recipientValid, hasQuote: !!quote, stage });
  const expired = quote ? now > Date.parse(quote.expiresAt) : false;
  const secondsLeft = quote ? Math.max(0, Math.round((Date.parse(quote.expiresAt) - now) / 1000)) : 0;
  const inFlight = busy || ["submitted", "source-confirming", "processing", "destination"].includes(stage);

  const resetQuote = useCallback(() => { setQuote(null); if (stage === "failed" || stage === "refunded" || stage === "complete") setStage("idle"); }, [stage]);
  useEffect(() => { setQuote(null); setError(""); }, [sourceChain, destChain, srcSymbol, dstSymbol, amount, recipient, slippageBps]);

  // keep token symbols valid when lists change
  useEffect(() => { if (srcTokens.length && !srcTokens.some((t) => t.symbol === srcSymbol)) setSrcSymbol(srcTokens[0].symbol); }, [srcTokens, srcSymbol]);
  useEffect(() => { if (dstTokens.length && !dstTokens.some((t) => t.symbol === dstSymbol)) setDstSymbol(dstTokens[0].symbol); }, [dstTokens, dstSymbol]);

  function payload(withWallet: boolean): QuotePayload | null {
    if (!srcToken || !dstToken || !amountBase) return null;
    const p: QuotePayload = {
      sourceChain, destinationChain: destChain,
      sourceToken: { symbol: srcToken.symbol, decimals: srcToken.decimals, address: srcToken.address, assetId: srcToken.assetId },
      destinationToken: { symbol: dstToken.symbol, decimals: dstToken.decimals, address: dstToken.address, assetId: dstToken.assetId },
      amount: amountBase.toString(), slippageBps,
    };
    if (sender) p.sender = sender;
    if (recipientValid) p.recipient = recipientTrim;
    return withWallet ? p : p;
  }

  function fail(msg: string, meta: { trackingId?: string; txHash?: string } = {}) {
    setError(msg); setErrorMeta(meta); setStage("failed"); setStatusText("");
  }

  // ---- 1) preview quote ----
  async function getQuote() {
    setError(""); setResult(null); setStage("idle");
    if (!route.ok) return setError(route.reason);
    if (!walletConnected) return setError(`Connect a ${src.name} wallet first.`);
    if (amountError || !amountBase) return setError(amountError || "Enter an amount.");
    if (!recipientValid) return setError(`Enter a valid ${dst.name} recipient address.`);
    const p = payload(true);
    if (!p) return setError("This route is temporarily unavailable.");
    try {
      setBusy(true);
      setQuote(await api.quote(p)); setNow(Date.now());
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Quote unavailable.");
    } finally { setBusy(false); }
  }

  // ---- 2) confirm: build → (approve) → sign → confirm → poll ----
  async function build(reviewed: NormalizedQuote): Promise<{ quote: NormalizedQuote; plan: TransactionPlan } | null> {
    const p = payload(true)!;
    const built = await api.build(p);
    const reviewedOut = BigInt(reviewed.amountOut), builtOut = BigInt(built.quote.amountOut);
    if (builtOut * 10_000n < reviewedOut * (10_000n - RATE_TOLERANCE_BPS)) {
      setQuote(built.quote); setNow(Date.now());
      setError("The rate moved while preparing your transaction. Nothing was sent — review the updated quote and confirm again.");
      setStage("idle"); setStatusText("");
      return null;
    }
    return built;
  }

  async function confirm() {
    if (!quote || !route.ok || !sender) return;
    if (expired) return getQuote();
    setError(""); setErrorMeta({}); setResult(null); setBusy(true);
    abortRef.current?.abort();
    const ctrl = new AbortController(); abortRef.current = ctrl;
    let txHash: string | undefined; let trackingId = quote.trackingId; let historyId: string | undefined;
    try {
      setStage("building"); setStatusText("Preparing your transaction…");
      let built = await build(quote); if (!built) return;

      if (built.plan.kind === "evm" && built.plan.approval) {
        setStage("approving");
        const approved = await approveIfNeeded(built.plan, sender as `0x${string}`, setStatusText);
        if (approved) { setStatusText("Approval confirmed. Refreshing your quote…"); const again = await build(built.quote); if (!again) return; built = again; }
      }
      setQuote(built.quote); setNow(Date.now());
      trackingId = built.quote.trackingId;

      setStage("wallet"); setStatusText("Confirm the transaction in your wallet…");
      const plan = built.plan;
      if (plan.kind === "evm") txHash = await sendEvmPlan(plan);
      else txHash = await sendSolanaPlan(plan, { wallet: sol, connection });

      historyId = crypto.randomUUID();
      const rec: HistoryItem = {
        id: historyId, createdAt: Date.now(), updatedAt: Date.now(), provider: built.quote.provider,
        sourceChain, destinationChain: destChain, sourceSymbol: srcToken!.symbol, sourceDecimals: srcToken!.decimals,
        destinationSymbol: dstToken!.symbol, destinationDecimals: dstToken!.decimals,
        amountIn: built.quote.amountIn, estimatedOut: built.quote.amountOut, sender, recipient: recipientTrim,
        txHash, trackingId, status: "submitted",
      };
      upsertHistory(rec);
      setStage("submitted"); setStatusText("Transaction submitted.");

      setStage("source-confirming"); setStatusText("Waiting for source-chain confirmation…");
      if (plan.kind === "evm") await waitEvmConfirmation(txHash as `0x${string}`, plan.chainId);
      else await waitSolanaConfirmation(txHash, connection);
      patchHistory(historyId, { status: "source-confirming" });

      if (built.quote.provider === "near-intents" && trackingId) {
        try { await api.submit({ provider: "near-intents", txHash, trackingId }); } catch { /* optional accelerator; status polling still works */ }
      }

      // ---- 3) poll provider until a terminal state. Success is shown ONLY when the provider reports settlement. ----
      if (!trackingId) throw new Error("No provider tracking id — check History.");
      setStage("processing"); setStatusText("Provider is processing your transfer…");
      const started = Date.now(); let failures = 0;
      while (!ctrl.signal.aborted && Date.now() - started < 30 * 60_000) {
        try {
          const s = await api.status({ provider: built.quote.provider, trackingId, txHash });
          failures = 0;
          patchHistory(historyId, { status: s.code === "unknown" ? "processing" : s.code, rawStatus: s.raw, destinationTxHash: s.destinationTxHash, error: s.message });
          if (s.code === "complete") { setResult({ destinationTxHash: s.destinationTxHash }); setStage("complete"); setStatusText(""); return; }
          if (s.code === "refunded") { setStage("refunded"); setError(s.message ?? "The transfer was refunded."); setErrorMeta({ trackingId, txHash }); setStatusText(""); return; }
          if (s.code === "failed") { fail(s.message ?? "The provider reported a failure.", { trackingId, txHash }); return; }
          if (s.destinationTxHash) setStage("destination");
          setStatusText(s.code === "source-confirming" || s.code === "awaiting-deposit" ? "Provider is detecting your deposit…" : "Provider is processing your transfer…");
        } catch { if (++failures >= 8) break; }
        await sleep(4000);
      }
      if (!ctrl.signal.aborted) {
        setStatusText(""); setStage("processing");
        setError("Still processing. Your transfer is safe — track it on the History page.");
        setErrorMeta({ trackingId, txHash });
      }
    } catch (e: any) {
      if (historyId) patchHistory(historyId, { status: "failed", error: humanizeWalletError(e) });
      fail(e instanceof ApiError ? e.message : humanizeWalletError(e), { trackingId, txHash });
    } finally { setBusy(false); }
  }

  function reset() { abortRef.current?.abort(); setStage("idle"); setError(""); setErrorMeta({}); setResult(null); setQuote(null); setStatusText(""); setAmount(""); }

  function swapArrow() {
    if (destChain === "near" || !SOURCE_CHAINS.includes(destChain)) return;
    const s = sourceChain; setSourceChain(destChain); setDestChain(s); setRecipient("");
  }

  const fillRecipient = () => {
    if (dst.family === "solana" && sol.publicKey) setRecipient(sol.publicKey.toBase58());
    else if (dst.family === "evm" && evm.address) setRecipient(evm.address);
  };
  const canFill = mounted && ((dst.family === "solana" && sol.connected) || (dst.family === "evm" && evm.isConnected));

  const terminal = stage === "complete" || stage === "failed" || stage === "refunded";
  const showStepper = mounted && (walletConnected || stage !== "idle");

  return (
    <div className="bridge-card" id="bridge">
      <div className="tabs"><button className="active">Bridge</button><a className="tabbtn" href="/history">Transaction History</a></div>

      <label>From</label>
      <div className="asset-row">
        <div className="asset-select">
          <span className={`coin ${coinClass(sourceChain)}`}>{coinLetter(sourceChain)}</span>
          <select aria-label="Source chain" value={sourceChain} disabled={inFlight} onChange={(e) => { const k = e.target.value as ChainKey; setSourceChain(k); if (k === destChain) setDestChain("near"); }}>
            {SOURCE_CHAINS.map((k) => <option key={k} value={k}>{CHAINS[k].name}</option>)}
          </select>
          <select aria-label="Source token" value={srcToken?.symbol ?? ""} disabled={inFlight || !srcTokens.length} onChange={(e) => setSrcSymbol(e.target.value)}>
            {srcTokens.map((t) => <option key={t.symbol} value={t.symbol}>{t.symbol}</option>)}
          </select>
        </div>
        <input aria-label="Amount" value={amount} disabled={inFlight} onChange={(e) => setAmount(e.target.value.replace(",", "."))} placeholder="0.00" inputMode="decimal" />
      </div>
      {evmWrongChain && (
        <button className="linkbtn" onClick={() => switchChainAsync({ chainId: src.evmChainId! }).catch(() => undefined)}>Your wallet is on another network — switch to {src.name}</button>
      )}

      <button className="swap-arrow" onClick={swapArrow} aria-label="Swap direction" disabled={inFlight || destChain === "near"}>↕</button>

      <label>To</label>
      <div className="asset-row destination">
        <div className="asset-select">
          <span className={`coin ${coinClass(destChain)}`}>{coinLetter(destChain)}</span>
          <select aria-label="Destination chain" value={destChain} disabled={inFlight} onChange={(e) => { setDestChain(e.target.value as ChainKey); setRecipient(""); }}>
            {DESTINATION_CHAINS.filter((k) => k !== sourceChain).map((k) => <option key={k} value={k}>{CHAINS[k].name}</option>)}
          </select>
          <select aria-label="Destination token" value={dstToken?.symbol ?? ""} disabled={inFlight || !dstTokens.length} onChange={(e) => setDstSymbol(e.target.value)}>
            {dstTokens.map((t) => <option key={t.symbol} value={t.symbol}>{t.symbol}</option>)}
          </select>
        </div>
        <span className="estimate">{quote && dstToken ? `≈ ${fmtToken(quote.amountOut, dstToken.decimals, undefined, 6)}` : "—"}</span>
      </div>

      <label>Recipient address ({dst.name})</label>
      <div className="addr-wrap">
        <input className="address" aria-label="Recipient" value={recipient} disabled={inFlight} onChange={(e) => setRecipient(e.target.value)}
          placeholder={dst.family === "near" ? "yourname.near" : dst.family === "solana" ? "Solana address" : "0x…"} spellCheck={false} autoComplete="off" />
        {canFill && !recipient && <button className="linkbtn" onClick={fillRecipient}>Use my connected wallet</button>}
      </div>
      {recipientTrim && !recipientValid && <div className="hint bad">Not a valid {dst.name} address.</div>}
      {dst.family === "near" && recipientValid && !recipientTrim.endsWith(".near") && !/^[0-9a-f]{64}$/.test(recipientTrim) && !/^0x/.test(recipientTrim) && (
        <div className="hint">Double-check this account exists — funds sent to a non-existent NEAR account may be unrecoverable.</div>
      )}

      {provider === "near-intents" && (
        <div className="slip"><span>Slippage</span>
          {[50, 100, 200].map((b) => <button key={b} className={"pill" + (slippageBps === b ? " on" : "")} disabled={inFlight} onClick={() => setSlippageBps(b)}>{b / 100}%</button>)}
        </div>
      )}

      {/* Fees — always visible; platform fee is never hidden */}
      <div className="fee-box">
        {quote && srcToken && dstToken ? (
          <>
            <div><span>Route</span><strong>{src.name} → {dst.name} · {quote.providerLabel}</strong></div>
            <div><span>You send</span><strong>{fmtToken(quote.amountIn, srcToken.decimals, srcToken.symbol)}</strong></div>
            {quote.fees.map((f) => (
              <div key={f.label}><span>{f.label}{f.platform ? ` (${(quote.platformFeeBps / 100).toFixed(2)}%)` : ""}</span><strong className={f.platform ? "plat" : ""}>{fmtFee(f)}</strong></div>
            ))}
            {quote.slippageBps != null && <div><span>Slippage tolerance</span><strong>{quote.slippageBps / 100}%</strong></div>}
            <div><span>Estimated time</span><strong>{fmtDuration(quote.estimatedSeconds)}</strong></div>
            {quote.minAmountOut && quote.minAmountOut !== quote.amountOut && <div><span>Minimum received</span><strong>{fmtToken(quote.minAmountOut, dstToken.decimals, dstToken.symbol)}</strong></div>}
            <div className="total"><span>Estimated received</span><strong>{fmtToken(quote.amountOut, dstToken.decimals, dstToken.symbol)}</strong></div>
            {!expired && !inFlight && !terminal && <div className="ttl">Quote valid for {secondsLeft}s</div>}
            {expired && !inFlight && <div className="ttl bad">Quote expired — refresh to continue.</div>}
          </>
        ) : (
          <>
            <div><span>Platform fee</span><strong className="plat">0.10%</strong></div>
            <div><span>Provider / network fees</span><strong>Dynamic</strong></div>
            <div className="total"><span>Estimated received</span><strong>Get a live quote</strong></div>
          </>
        )}
      </div>
      {quote?.warnings.map((w) => <div className="hint" key={w}>{w}</div>)}

      {providerDown && <div className="err">Route unavailable: {providerHealth?.reason}</div>}
      {ocError && destChain === "near" && <div className="err">{ocError}</div>}
      {amountError && <div className="hint bad">{amountError}</div>}
      {error && (
        <div className={stage === "refunded" ? "warnbox" : "err"} role="alert">
          {error}
          {(errorMeta.trackingId || errorMeta.txHash) && (
            <div className="ids">
              {errorMeta.trackingId && <div>{provider === "near-intents" ? "Deposit address" : "Order ID"}: <code>{errorMeta.trackingId}</code></div>}
              {errorMeta.txHash && <div>Tx: <code>{errorMeta.txHash}</code></div>}
            </div>
          )}
        </div>
      )}
      {statusText && <div className="status"><span /> {statusText}</div>}
      {stage === "complete" && (
        <div className="success" role="status">
          ✓ Delivered. The provider confirmed settlement on {dst.name}.
          {result?.destinationTxHash && dst.explorerTx && <div><a href={dst.explorerTx(result.destinationTxHash)} target="_blank" rel="noreferrer">View destination transaction ↗</a></div>}
        </div>
      )}

      {showStepper && <StepTracker step={step} failed={stage === "failed" || stage === "refunded"} />}

      {terminal ? (
        <button className="mainbtn" onClick={reset}>{stage === "complete" ? "Start another transfer" : "Start over"}</button>
      ) : !walletConnected ? (
        <button className="mainbtn" disabled>Connect a {src.name} wallet to continue</button>
      ) : !quote || expired ? (
        <button className="mainbtn" disabled={busy || !!providerDown || !route.ok || inFlight} onClick={getQuote}>{busy ? "Getting quote…" : expired ? "Refresh quote" : "Get live quote"}</button>
      ) : (
        <button className="mainbtn" disabled={inFlight} onClick={confirm}>{inFlight ? "Processing…" : "Confirm & Send"}</button>
      )}
      {!route.ok && <div className="hint bad">{route.reason}</div>}
      <p className="legal">Non-custodial: you sign every transaction in your own wallet. NearPort never holds your funds. Independent app; not affiliated with NEAR Foundation, deBridge or NEAR Intents.</p>
    </div>
  );
}
