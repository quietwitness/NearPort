"use client";
import { useEffect, useRef } from "react";
import { CHAINS } from "@/lib/chains";
import { api } from "@/lib/client/api";
import { clearHistory, HistoryItem, patchHistory, TERMINAL, useHistory } from "@/lib/client/history";
import { fmtToken, shortAddress } from "@/lib/format";

const LABEL: Record<HistoryItem["status"], string> = {
  submitted: "Submitted", "awaiting-deposit": "Awaiting deposit", "source-confirming": "Confirming on source", processing: "Provider processing",
  complete: "Complete", refunded: "Refunded", failed: "Failed", unknown: "Processing",
};

export function HistoryList() {
  const items = useHistory();
  const itemsRef = useRef(items);
  itemsRef.current = items;

  // Refresh non-terminal items from the provider. Status is only ever "complete" if the provider says so.
  useEffect(() => {
    let stop = false;
    async function tick() {
      for (const it of itemsRef.current) {
        if (stop || TERMINAL.includes(it.status) || !it.trackingId) continue;
        if (Date.now() - it.createdAt > 3 * 24 * 3600_000) continue;
        try {
          const s = await api.status({ provider: it.provider, trackingId: it.trackingId, txHash: it.txHash });
          patchHistory(it.id, { status: s.code === "unknown" ? "processing" : s.code, rawStatus: s.raw, destinationTxHash: s.destinationTxHash, error: s.message });
        } catch { /* keep last known status */ }
      }
    }
    tick();
    const t = setInterval(tick, 10_000);
    return () => { stop = true; clearInterval(t); };
  }, []);

  if (!items.length) return <p className="muted">No transfers yet. Transfers you make from this browser will appear here.</p>;

  return (
    <div className="history">
      {items.map((it) => {
        const s = CHAINS[it.sourceChain], d = CHAINS[it.destinationChain];
        return (
          <article key={it.id} className={`hitem ${it.status}`}>
            <header>
              <b>{fmtToken(it.amountIn, it.sourceDecimals, it.sourceSymbol)} <span>{s.name} → {d.name}</span></b>
              <em className={`badge ${it.status}`}>{LABEL[it.status]}</em>
            </header>
            <dl>
              <div><dt>Est. received</dt><dd>{fmtToken(it.estimatedOut, it.destinationDecimals, it.destinationSymbol)}</dd></div>
              <div><dt>Recipient</dt><dd>{shortAddress(it.recipient, 6, 6)}</dd></div>
              <div><dt>Provider</dt><dd>{it.provider === "near-intents" ? "NEAR Intents" : "deBridge"}</dd></div>
              <div><dt>Started</dt><dd>{new Date(it.createdAt).toLocaleString()}</dd></div>
              {it.txHash && <div><dt>Source tx</dt><dd>{s.explorerTx ? <a href={s.explorerTx(it.txHash)} target="_blank" rel="noreferrer">{shortAddress(it.txHash, 8, 6)} ↗</a> : shortAddress(it.txHash, 8, 6)}</dd></div>}
              {it.destinationTxHash && <div><dt>Destination tx</dt><dd>{d.explorerTx ? <a href={d.explorerTx(it.destinationTxHash)} target="_blank" rel="noreferrer">{shortAddress(it.destinationTxHash, 8, 6)} ↗</a> : shortAddress(it.destinationTxHash, 8, 6)}</dd></div>}
              {it.trackingId && <div><dt>{it.provider === "near-intents" ? "Deposit address" : "Order ID"}</dt><dd><code>{shortAddress(it.trackingId, 8, 6)}</code></dd></div>}
            </dl>
            {it.error && <p className="hint bad">{it.error}</p>}
          </article>
        );
      })}
      <button className="linkbtn" onClick={() => { if (confirm("Clear the transfer history stored in this browser?")) clearHistory(); }}>Clear local history</button>
    </div>
  );
}
