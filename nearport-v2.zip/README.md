# NearPort — Your gateway to NEAR

**Move value. Arrive on NEAR.** A non-custodial portal to move assets from Solana and EVM chains (Ethereum, Base, Arbitrum) to NEAR, and between those chains. NearPort is the interface and router; it does **not** run a bridge and **never holds funds or keys**. Your own wallet signs every transaction.

## 1. What it does
Connect a Solana or EVM wallet → enter amount and recipient → get a live quote → review fees → confirm in your wallet → track until the provider confirms settlement.
Supported: SOL/ETH/Base/Arbitrum → NEAR; SOL ↔ ETH/Base/Arbitrum; EVM ↔ EVM. Tokens: native assets, USDC, USDT (where available).

## 2. Architecture
```
Wallet → UI (components/) → API routes (app/api/*, server-side) → Route engine (lib/routing/engine.ts)
      → Provider adapter: NEAR Intents (lib/providers/near-intents.ts) | deBridge (lib/providers/debridge.ts)
      → user signs (lib/wallet/execute.ts) → provider executes → destination wallet
```
Rule: destination NEAR → NEAR Intents; otherwise → deBridge. Add providers by implementing `ProviderAdapter` (`getQuote`, `buildTransaction`, `submit`, `getStatus`) in `lib/providers/types.ts` and adding a rule in the route engine.

## 3. Provider integrations (verified against current docs, Sep 2026)
- **NEAR Intents 1Click**: `/v0/tokens`, `/v0/quote` (dry preview, then real quote with deposit address), `/v0/deposit/submit`, `/v0/status`. Success only on `SUCCESS`.
- **deBridge DLN**: `dln/order/create-tx` (quote + tx in one call, valid ~30s), status from `dln-api.debridge.finance/api/Orders/{id}/state`. Success only on `Fulfilled`/`SentUnlock`/`ClaimedUnlock`. Cancelled states show as refunded.

## 4. Environment variables
See `.env.example` (every variable is documented there). Nothing is required to launch **NEAR routes**. deBridge routes need `DEBRIDGE_REFERRAL_CODE`.

| Variable | Needed? | Notes |
|---|---|---|
| `FEE_NEAR_ACCOUNT`, `FEE_SOLANA_ADDRESS`, `FEE_EVM_ADDRESS` | yes (prefilled) | Public fee addresses |
| `ONECLICK_JWT` | optional | Server-side secret. Without it 1Click adds 25 bps on top of NearPort's fee |
| `DEBRIDGE_REFERRAL_CODE` | for deBridge routes | Free, from app.debridge.com/refer |
| `DEBRIDGE_SOLANA_AFFILIATE_RECIPIENT` | for Solana-source deBridge | Prefilled with your Solana address |
| `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` | optional | Enables mobile/QR wallets |
| `SOLANA_RPC_URL` | recommended | Private RPC (server-side, proxied) |

## 5. Local development
`npm install` → copy `.env.example` to `.env.local` → `npm run dev` → open http://localhost:3000.

## 6. Vercel deployment
1. Push this folder to a GitHub repo. 2. vercel.com → Add New Project → import it. 3. Settings → Environment Variables → paste the values from `.env.example`. 4. Deploy. 5. Settings → Domains to attach your domain.
Or CLI: `npm i -g vercel && vercel --prod`. Set `NEXT_PUBLIC_SITE_URL` to your domain.

## 7. Wallets
Solana: Phantom, Solflare (wallet-adapter). EVM: any browser wallet (EIP-6963: MetaMask, Rabby, Coinbase…) + WalletConnect when the project id is set. Mobile: modal offers "Open in Phantom / MetaMask app" deep links. NEAR: users just type their NEAR account; no NEAR wallet is connected. Add EVM networks in `lib/wallet/wagmi-config.ts` + `lib/chains.ts` + `lib/tokens.ts`.

## 8. Fees (0.10% = 10 bps)
Charged only through provider-native mechanisms — never a frontend-only fee. The UI shows "NearPort fee (0.10%)" separately from provider and network fees.
- **NEAR Intents**: `appFees` in basis points, taken from input. Per docs, with a JWT the fee is split 50/50 with 1Click (their half has a 20 bps floor), so NearPort requests **20 bps to keep 10 bps** (user pays 30 bps total: 10 NearPort + 20 NEAR Intents). Without a JWT, NearPort requests 10 and 1Click adds 25 (35 total). Override with `ONECLICK_APP_FEE_REQUEST_BPS` if your partner agreement differs.
- **deBridge**: `affiliateFeePercent=0.1` (percent, not bps) + `affiliateFeeRecipient` on the **origin** chain.

## 9. deBridge affiliate setup
1. Open app.debridge.com/refer, connect a wallet, generate a referral code (Polygon is cheapest and works for all chains). Put it in `DEBRIDGE_REFERRAL_CODE`.
2. EVM-source fees go automatically to `FEE_EVM_ADDRESS` when a solver claims the order.
3. Solana-source fees go to `DEBRIDGE_SOLANA_AFFILIATE_RECIPIENT` (a Solana public key) but must be **withdrawn manually** via the DLN program's `withdrawAffiliateFee` (deBridge docs: "Withdrawing affiliate fees"). The Jupiter referral key is only needed for same-chain Solana swaps, which NearPort does not do.
Until these are set, deBridge routes return a clear configuration error instead of silently skipping the fee.

## 10. NEAR Intents setup
Works immediately without credentials. For better economics, request a JWT at partners.near-intents.org and set `ONECLICK_JWT` (server-side only). There is no testnet; test with small amounts.

## 11. Security notes
No keys or seed phrases anywhere; nothing is signed server-side. Secrets are read only in server code (`server-only`); `npm run check:bundle` scans the browser bundle for them. Strict input validation (chains, addresses, amounts, slippage 0.01–5%), unknown request fields rejected, same-origin check, per-IP rate limits (in-memory per serverless instance — add Vercel Firewall for stronger protection), Solana RPC proxy with method allow-list, provider responses checked against the requested route/amount, quote expiry (30s for deBridge), rate-move guard (>0.5% worse → asks again), security headers. History is stored only in the user's browser.
**Before real launch:** add Terms/Privacy pages and get legal advice on compliance in your jurisdiction; run a small real transfer on each route.

## 12. Testing
`npm test` (35 unit tests: validation, routing, fee math, both adapters with mocked providers, status mapping) · `npm run build && npm run check:bundle` · `npm run typecheck`.
Live-provider calls could not be exercised in the build sandbox, so do a small real transfer per route after deploy.
